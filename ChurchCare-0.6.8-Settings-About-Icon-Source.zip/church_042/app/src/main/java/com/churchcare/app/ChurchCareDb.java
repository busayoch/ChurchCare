package com.churchcare.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Shared local database schema and offline synchronization foundation.
 *
 * The local SQLite database remains the authoritative offline working store.
 * Sync metadata is deliberately kept separate from business records so a
 * future cloud provider can be added without redesigning the core data model.
 */
public final class ChurchCareDb {
    public static final int VERSION = 13;
    public static final String DB_NAME = "churchcare.db";

    private ChurchCareDb() {}

    public static void ensureAll(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS members (member_id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, phone_number TEXT, created_at INTEGER NOT NULL, date_of_birth TEXT, address TEXT, status TEXT DEFAULT 'Active', notes TEXT, photo1_uri TEXT, photo2_uri TEXT, photo3_uri TEXT, photo2_quality TEXT DEFAULT 'standard', photo3_quality TEXT DEFAULT 'standard', latitude REAL, longitude REAL, location_source TEXT)");
        addColumnIfMissing(db,"members","date_of_birth","TEXT");
        addColumnIfMissing(db,"members","address","TEXT");
        addColumnIfMissing(db,"members","status","TEXT DEFAULT 'Active'");
        addColumnIfMissing(db,"members","notes","TEXT");
        addColumnIfMissing(db,"members","photo1_uri","TEXT");
        addColumnIfMissing(db,"members","photo2_uri","TEXT");
        addColumnIfMissing(db,"members","photo3_uri","TEXT");
        addColumnIfMissing(db,"members","photo2_quality","TEXT DEFAULT 'standard'");
        addColumnIfMissing(db,"members","photo3_quality","TEXT DEFAULT 'standard'");
        addColumnIfMissing(db,"members","latitude","REAL");
        addColumnIfMissing(db,"members","longitude","REAL");
        addColumnIfMissing(db,"members","location_source","TEXT");
        addColumnIfMissing(db,"members","organization_id","INTEGER");

        db.execSQL("CREATE TABLE IF NOT EXISTS statuses (status_id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,sort_order INTEGER NOT NULL)");
        seedStatuses(db);
        db.execSQL("CREATE TABLE IF NOT EXISTS member_visits (visit_id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL, visit_date INTEGER NOT NULL, visit_type TEXT NOT NULL, member_status TEXT, notes TEXT, care_need INTEGER NOT NULL DEFAULT 0)");
        db.execSQL("CREATE TABLE IF NOT EXISTS care_tickets (ticket_id INTEGER PRIMARY KEY AUTOINCREMENT, member_id INTEGER NOT NULL, category TEXT NOT NULL, description TEXT, estimated_cost REAL, handling_org TEXT, assigned_to TEXT, follow_up_at INTEGER, resolution_note TEXT, status TEXT NOT NULL DEFAULT 'OPEN', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
        addColumnIfMissing(db,"care_tickets","assigned_to","TEXT");
        addColumnIfMissing(db,"care_tickets","follow_up_at","INTEGER");
        addColumnIfMissing(db,"care_tickets","resolution_note","TEXT");
        addColumnIfMissing(db,"care_tickets","handling_org_id","INTEGER");
        db.execSQL("CREATE TABLE IF NOT EXISTS care_ticket_events (event_id INTEGER PRIMARY KEY AUTOINCREMENT, ticket_id INTEGER NOT NULL, from_status TEXT, to_status TEXT, event_type TEXT NOT NULL, from_org TEXT, to_org TEXT, event_time INTEGER NOT NULL, note TEXT)");
        db.execSQL("CREATE TABLE IF NOT EXISTS care_categories (category_id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT NOT NULL UNIQUE,sort_order INTEGER NOT NULL,enabled INTEGER NOT NULL DEFAULT 1)");
        seedCareCategories(db);
        db.execSQL("CREATE TABLE IF NOT EXISTS church_profile (church_id INTEGER PRIMARY KEY AUTOINCREMENT, church_name TEXT NOT NULL, join_code TEXT NOT NULL UNIQUE, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS hierarchy_levels (level_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE, sort_order INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE IF NOT EXISTS organizations (organization_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, level_id INTEGER NOT NULL, parent_id INTEGER, join_code TEXT UNIQUE, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS leadership_assignments (assignment_id INTEGER PRIMARY KEY AUTOINCREMENT, organization_id INTEGER NOT NULL, person_name TEXT NOT NULL, role_name TEXT NOT NULL, reports_to_name TEXT, created_at INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE IF NOT EXISTS pastors (person_id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, phone TEXT, created_at INTEGER NOT NULL, enabled INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE IF NOT EXISTS pastoral_appointments (appointment_id INTEGER PRIMARY KEY AUTOINCREMENT, person_id INTEGER NOT NULL, organization_id INTEGER NOT NULL, role_name TEXT NOT NULL, start_at INTEGER NOT NULL, end_at INTEGER, change_type TEXT NOT NULL, previous_appointment_id INTEGER, notes TEXT, created_at INTEGER NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS delegations (delegation_id INTEGER PRIMARY KEY AUTOINCREMENT, overseer_person TEXT NOT NULL, delegate_person TEXT NOT NULL, organization_id INTEGER, role_name TEXT, start_at INTEGER NOT NULL, end_at INTEGER, enabled INTEGER NOT NULL DEFAULT 1, notes TEXT, created_at INTEGER NOT NULL)");
        seedHierarchy(db);

        ensureSyncFoundation(db);
    }

    private static void ensureSyncFoundation(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS sync_records (" +
                "sync_id TEXT PRIMARY KEY," +
                "entity_type TEXT NOT NULL," +
                "local_id INTEGER NOT NULL," +
                "state TEXT NOT NULL DEFAULT 'PENDING'," +
                "created_at INTEGER NOT NULL," +
                "updated_at INTEGER NOT NULL," +
                "deleted_at INTEGER," +
                "last_synced_at INTEGER," +
                "sync_attempts INTEGER NOT NULL DEFAULT 0," +
                "last_error TEXT," +
                "UNIQUE(entity_type,local_id))");

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_records_state ON sync_records(state,updated_at)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_records_entity ON sync_records(entity_type,local_id)");

        db.execSQL("CREATE TABLE IF NOT EXISTS sync_queue (" +
                "queue_id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "sync_id TEXT NOT NULL," +
                "entity_type TEXT NOT NULL," +
                "local_id INTEGER NOT NULL," +
                "operation TEXT NOT NULL," +
                "payload_json TEXT," +
                "created_at INTEGER NOT NULL," +
                "attempt_count INTEGER NOT NULL DEFAULT 0," +
                "status TEXT NOT NULL DEFAULT 'PENDING'," +
                "last_attempt_at INTEGER," +
                "last_error TEXT)");

        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_queue_status ON sync_queue(status,queue_id)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_sync_queue_sync_id ON sync_queue(sync_id)");

        db.execSQL("CREATE TABLE IF NOT EXISTS sync_state (" +
                "state_id INTEGER PRIMARY KEY CHECK(state_id=1)," +
                "last_pull_cursor TEXT," +
                "last_sync_at INTEGER," +
                "last_success_at INTEGER," +
                "last_error TEXT," +
                "is_syncing INTEGER NOT NULL DEFAULT 0)");

        ContentValues state = new ContentValues();
        state.put("state_id", 1);
        state.put("is_syncing", 0);
        db.insertWithOnConflict("sync_state", null, state, SQLiteDatabase.CONFLICT_IGNORE);

        // Existing records receive stable IDs and are marked pending once.
        backfillSyncRecords(db);

        String[] tables = {
                "members","member_visits","care_tickets","care_ticket_events",
                "care_categories","organizations","leadership_assignments",
                "pastors","pastoral_appointments","delegations"
        };
        for (String table : tables) createSyncTriggers(db, table);

        // The business tables below are intentionally not treated as syncable
        // entities: statuses/categories may be local configuration and church
        // profile is tenant configuration. Categories are included above so
        // cloud copies can preserve a church's configured care taxonomy.
    }

    private static void backfillSyncRecords(SQLiteDatabase db) {
        String[] tables = {
                "members","member_visits","care_tickets","care_ticket_events",
                "care_categories","organizations","leadership_assignments",
                "pastors","pastoral_appointments","delegations"
        };
        for (String table : tables) {
            String id = primaryId(table);
            Cursor c = db.rawQuery("SELECT " + id + " FROM " + table +
                    " WHERE " + id + " NOT IN (SELECT local_id FROM sync_records WHERE entity_type=?)",
                    new String[]{table});
            try {
                while (c.moveToNext()) {
                    long localId = c.getLong(0);
                    ContentValues v = new ContentValues();
                    v.put("sync_id", newSyncId());
                    v.put("entity_type", table);
                    v.put("local_id", localId);
                    v.put("state", "PENDING");
                    v.put("created_at", System.currentTimeMillis());
                    v.put("updated_at", System.currentTimeMillis());
                    db.insertWithOnConflict("sync_records", null, v, SQLiteDatabase.CONFLICT_IGNORE);

                    Cursor q = db.rawQuery("SELECT sync_id FROM sync_records WHERE entity_type=? AND local_id=?",
                            new String[]{table,String.valueOf(localId)});
                    try {
                        if (q.moveToFirst()) {
                            enqueueRaw(db, q.getString(0), table, localId, "UPSERT",
                                    "{\"local_id\":"+localId+"}");
                        }
                    } finally { q.close(); }
                }
            } finally { c.close(); }
        }
    }

    private static void createSyncTriggers(SQLiteDatabase db, String table) {
        String id = primaryId(table);
        String ins = "trg_sync_" + table + "_insert";
        String upd = "trg_sync_" + table + "_update";
        String del = "trg_sync_" + table + "_delete";

        db.execSQL("DROP TRIGGER IF EXISTS " + ins);
        db.execSQL("DROP TRIGGER IF EXISTS " + upd);
        db.execSQL("DROP TRIGGER IF EXISTS " + del);

        db.execSQL("CREATE TRIGGER " + ins + " AFTER INSERT ON " + table + " BEGIN " +
                "INSERT OR IGNORE INTO sync_records(sync_id,entity_type,local_id,state,created_at,updated_at) " +
                "VALUES(lower(hex(randomblob(16))),'" + table + "',NEW." + id + ",'PENDING',strftime('%s','now')*1000,strftime('%s','now')*1000);" +
                "INSERT INTO sync_queue(sync_id,entity_type,local_id,operation,payload_json,created_at) " +
                "SELECT sync_id,'" + table + "',NEW." + id + ",'UPSERT','{\"local_id\":' || NEW." + id + " || '}',strftime('%s','now')*1000 " +
                "FROM sync_records WHERE entity_type='" + table + "' AND local_id=NEW." + id + ";" +
                "END");

        db.execSQL("CREATE TRIGGER " + upd + " AFTER UPDATE ON " + table + " BEGIN " +
                "INSERT OR IGNORE INTO sync_records(sync_id,entity_type,local_id,state,created_at,updated_at) " +
                "VALUES(lower(hex(randomblob(16))),'" + table + "',NEW." + id + ",'PENDING',strftime('%s','now')*1000,strftime('%s','now')*1000);" +
                "UPDATE sync_records SET state='PENDING',updated_at=strftime('%s','now')*1000,deleted_at=NULL WHERE entity_type='" + table + "' AND local_id=NEW." + id + ";" +
                "INSERT INTO sync_queue(sync_id,entity_type,local_id,operation,payload_json,created_at) " +
                "SELECT sync_id,'" + table + "',NEW." + id + ",'UPSERT','{\"local_id\":' || NEW." + id + " || '}',strftime('%s','now')*1000 " +
                "FROM sync_records WHERE entity_type='" + table + "' AND local_id=NEW." + id + ";" +
                "END");

        db.execSQL("CREATE TRIGGER " + del + " AFTER DELETE ON " + table + " BEGIN " +
                "UPDATE sync_records SET state='TOMBSTONE',deleted_at=strftime('%s','now')*1000,updated_at=strftime('%s','now')*1000 WHERE entity_type='" + table + "' AND local_id=OLD." + id + ";" +
                "INSERT INTO sync_queue(sync_id,entity_type,local_id,operation,payload_json,created_at) " +
                "SELECT sync_id,'" + table + "',OLD." + id + "','DELETE','{\"local_id\":' || OLD." + id + " || '}',strftime('%s','now')*1000 " +
                "FROM sync_records WHERE entity_type='" + table + "' AND local_id=OLD." + id + ";" +
                "END");
    }

    private static void enqueueRaw(SQLiteDatabase db, String syncId, String entity, long localId,
                                   String operation, String payload) {
        ContentValues q = new ContentValues();
        q.put("sync_id", syncId);
        q.put("entity_type", entity);
        q.put("local_id", localId);
        q.put("operation", operation);
        q.put("payload_json", payload);
        q.put("created_at", System.currentTimeMillis());
        q.put("status", "PENDING");
        db.insert("sync_queue", null, q);
    }

    private static String primaryId(String table) {
        if ("members".equals(table)) return "member_id";
        if ("member_visits".equals(table)) return "visit_id";
        if ("care_tickets".equals(table)) return "ticket_id";
        if ("care_ticket_events".equals(table)) return "event_id";
        if ("care_categories".equals(table)) return "category_id";
        if ("organizations".equals(table)) return "organization_id";
        if ("leadership_assignments".equals(table)) return "assignment_id";
        if ("pastors".equals(table)) return "person_id";
        if ("pastoral_appointments".equals(table)) return "appointment_id";
        if ("delegations".equals(table)) return "delegation_id";
        throw new IllegalArgumentException("Unknown sync table: " + table);
    }

    private static String newSyncId() {
        return java.util.UUID.randomUUID().toString();
    }

    public static String getSyncId(SQLiteDatabase db, String entityType, long localId) {
        Cursor c = db.rawQuery("SELECT sync_id FROM sync_records WHERE entity_type=? AND local_id=?",
                new String[]{entityType, String.valueOf(localId)});
        try { return c.moveToFirst() ? c.getString(0) : null; } finally { c.close(); }
    }

    public static int pendingSyncCount(SQLiteDatabase db) {
        Cursor c = db.rawQuery("SELECT COUNT(*) FROM sync_queue WHERE status='PENDING'", null);
        try { return c.moveToFirst() ? c.getInt(0) : 0; } finally { c.close(); }
    }

    public static void markQueueAttempt(SQLiteDatabase db, long queueId, String error) {
        ContentValues v = new ContentValues();
        v.put("attempt_count", 1);
        v.put("last_attempt_at", System.currentTimeMillis());
        if (error == null) {
            v.put("status", "SENT");
            v.putNull("last_error");
        } else {
            v.put("status", "FAILED");
            v.put("last_error", error);
        }
        db.update("sync_queue", v, "queue_id=?", new String[]{String.valueOf(queueId)});
    }

    private static void addColumnIfMissing(SQLiteDatabase db,String table,String column,String definition){
        Cursor c=db.rawQuery("PRAGMA table_info("+table+")",null); boolean found=false;
        try{while(c.moveToNext()){if(column.equalsIgnoreCase(c.getString(c.getColumnIndexOrThrow("name")))){found=true;break;}}}finally{c.close();}
        if(!found) db.execSQL("ALTER TABLE "+table+" ADD COLUMN "+column+" "+definition);
    }
    private static void seedStatuses(SQLiteDatabase db){String[] a={"Active","Needs Follow-up","Inactive","Hospitalized","New Convert"};for(int i=0;i<a.length;i++){ContentValues v=new ContentValues();v.put("name",a[i]);v.put("sort_order",i+1);db.insertWithOnConflict("statuses",null,v,SQLiteDatabase.CONFLICT_IGNORE);}}
    private static void seedCareCategories(SQLiteDatabase db){String[] a={"Financial","Medical","Housing","Employment","Spiritual"};for(int i=0;i<a.length;i++){ContentValues v=new ContentValues();v.put("name",a[i]);v.put("sort_order",i+1);v.put("enabled",1);db.insertWithOnConflict("care_categories",null,v,SQLiteDatabase.CONFLICT_IGNORE);}}
    private static void seedHierarchy(SQLiteDatabase db){Cursor c=db.rawQuery("SELECT COUNT(*) FROM hierarchy_levels",null);try{if(c.moveToFirst()&&c.getInt(0)==0){String[] a={"Church","District","Local Church"};for(int i=0;i<a.length;i++){ContentValues v=new ContentValues();v.put("name",a[i]);v.put("sort_order",i+1);v.put("enabled",1);db.insert("hierarchy_levels",null,v);}}}finally{c.close();}}
}
