# ChurchCare Change Log

## 0.6.8 — Operational Backend Foundation
- Advanced database version from 12 to 13.
- Preserved SQLite as the authoritative offline working database.
- Added `sync_records` with stable client-side synchronization IDs and lifecycle state.
- Added durable `sync_queue` with operation, payload reference, retry count, status,
  timestamp and error fields.
- Added `sync_state` for synchronization-in-progress state, last pull cursor,
  last sync time, last successful sync and last error.
- Added SQLite triggers for INSERT/UPDATE/DELETE on core synchronized entities.
- Existing core records are backfilled into synchronization metadata and queued as
  initial UPSERT operations.
- Deleted records are represented as synchronization tombstones so a future
  remote provider can propagate deletes safely.
- Added `organization_id` to members to prepare member-to-organization relationships.
- Added `handling_org_id` to care tickets while retaining the existing display field.
- Added a dedicated `delegations` table supporting zero-to-many delegated workers.
- Added `ChurchCareSync` as a dependency-free local queue coordinator; remote/cloud
  transport remains intentionally deferred.
- Preserved the five-most-recent-visits privacy rule.
- Preserved thumbnail-only default cloud photo synchronization and local additional
  photographs.
- Preserved existing 0.6.7 UI and workflows as the baseline.


ChurchCare 0.6.6

Privacy-first visit retention: only the five most recent visit records are retained per member. Older visit records are automatically removed when a new visit takes the total above five.

ChurchCare 0.6.4 adds the Member Management search/filter workflow and real member summary counts.

# ChurchCare Change Log

The project is developed incrementally from stable phone-tested builds.

## Current
- 0.4.2: Visit/Visitation Log placed before Care Management in the member flow.
- 0.4.1: Care categories made configurable; add, rename, and safe-delete.
- 0.4.0: Care Management and care tickets.
- 0.3.0: Field Follow-up and visitation history.
- 0.2.5: SD/HD toggle corrected; SD left/default, HD right.
- 0.2.4: Subtle HD toggle beside live-photo slots.
- 0.2.3: Standard default and once-per-day HD warning.
- 0.2.2: Optional location and configurable member statuses.
- 0.2.1: Photo quality and manual profile crop foundation.
- 0.5.0: Configurable Church Structure foundation.

## Design rule
Church terminology, categories, statuses, types, and hierarchy levels should be configurable wherever practical. Seeded values are defaults, not permanent assumptions.

## 0.5.1
Leadership & Delegation was added. A person may be designated to work on behalf of a pastor/leader, with a configurable responsibility and reporting-to relationship. The shared SQLite schema was also consolidated to prevent member-save crashes caused by screen-specific database initialization.


Current build: ChurchCare 0.5.1 — Leadership & Delegation + Database Reliability.


## 0.5.7 — Visual Structure Syntax Cleanup
- Fixed the remaining `addOrganization(...)` argument mismatch in the empty-level visual-tree control.
- Reviewed all `addOrganization(...)` call sites in `StructureManagerActivity.java` for the two-argument API.
- Preserved the working member-save/database reliability fix and existing visual-structure behavior.
- Included the original ChurchCare Master Work Sheet with this project archive for continuity.

## 0.6.0
Pastoral Transfers & Promotions. Added person-based pastoral appointment history so transfers, promotions, and promotion+transfer events do not alter the church tree or local church data. Appointment history is retained for traceability.
