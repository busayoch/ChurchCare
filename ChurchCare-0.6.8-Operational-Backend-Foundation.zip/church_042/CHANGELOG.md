# ChurchCare Change Log

## 0.6.8 — Operational Backend Foundation
- Advanced database version from 12 to 13.
- Preserved SQLite as the authoritative offline working database.
- Added `sync_records` with stable client-side synchronization IDs and lifecycle state.
- Added durable `sync_queue` with operation, payload reference, retry count, status,
  timestamp and error fields.
- Added `sync_state` for synchronization-in-progress state, last pull cursor,
  last sync time, last successful sync and last error.
- Added SQLite triggers for INSERT/UPDATE/DELETE on core synchronized entities.
- Existing core records are backfilled into synchronization metadata and queued as
  initial UPSERT operations.
- Deleted records are represented as synchronization tombstones so a future
  remote provider can propagate deletes safely.
- Added `organization_id` to members to prepare member-to-organization relationships.
- Added `handling_org_id` to care tickets while retaining the existing display field.
- Added a dedicated `delegations` table supporting zero-to-many delegated workers.
- Added `ChurchCareSync` as a dependency-free local queue coordinator; remote/cloud
  transport remains intentionally deferred.
- Preserved the five-most-recent-visits privacy rule.
- Preserved thumbnail-only default cloud photo synchronization and local additional
  photographs.
- Preserved existing 0.6.7 UI and workflows as the baseline.

## 0.6.6 — Privacy-First Visit Retention
- Added a privacy-first retention rule for member visit records: ChurchCare keeps only the **5 most recent visits per member**.
- When a new visit is saved and the member already has more than five records, older visit records are automatically removed.
- The member profile labels the visit section as **Recent visit history (last 5)** to make the retention policy clear.
- This limit is intentional: ChurchCare should support care and follow-up without unnecessarily retaining a long record of a member's past.
- No member profile, photograph, care-ticket, church-structure, pastoral appointment, or delegation data is removed by this policy.

# ChurchCare Change Log

## 0.6.4 — Member Management Workflow
- Added fast member search by full name or phone number.
- Added configurable status filtering using the church's current status list.
- Member cards now show the current member status alongside the phone information.
- Empty search/filter results are clearly distinguished from an empty member database.
- Member Summary now reports actual visit count, care-ticket count, and member-since date from local SQLite data instead of placeholder values.
- Preserved offline-first local storage and existing photo, visit, care, structure, pastoral appointment, and delegation functionality.
- Database version advanced to 11.

## 0.5.5 — Visual Structure Child-Add Compile Fix

- Fixed child-organization creation call signature in the visual structure editor.
- Preserved automatic parent selection when adding a child from an organization card.
- No database schema changes.

# ChurchCare Change Log

## 0.5.3 — Visual Structure UI & Empty Organizations
- Made the **Visual Organization Structure** the primary/default Church Structure view.
- Added a dedicated horizontally scrollable visual hierarchy area.
- Sibling organizations at the same level are shown side-by-side.
- Added clear **+ Add another [Level]** controls beside each sibling group.
- Added **+ Child** directly to an organization for creating its next-level child.
- Empty organizations remain visible and are explicitly shown as having no child organizations.
- Organizations can therefore exist at any configured level without requiring children.
- Kept hierarchy-level management and Leadership & Delegation as secondary tools.
- Preserved the 0.5.1 shared database/member-save fix and existing functionality.
- Version updated to 0.5.3.

0.4.1 — Configurable Care Categories
- Added a dedicated **Care Categories** manager.
- Each church can add new care categories.
- Existing categories can be renamed/edited.
- Categories not used by any existing care ticket can be deleted.
- Categories already used by care tickets are protected from deletion so historical records are not damaged; the category can be renamed instead.
- Care-ticket creation now loads the enabled categories from the local database rather than a hard-coded list.
- Seeded the original Financial, Medical, Housing, Employment, and Spiritual categories for existing/new installations.
- Database upgraded to version 7.

## 0.2.5 — Live Photo SD/HD Toggle Label Fix
- Clarified the live-photo quality control with **SD on the left** and **HD on the right**.
- The switch is unlabeled itself so the quality names remain horizontal and readable.
- **SD/off is the default** for both Live Photo 1 and Live Photo 2.
- Kept the existing once-per-day HD warning behavior.

# ChurchCare Change Log

## 0.2.4 — Live Photo Quality Toggle
- Replaced the separate live-photo quality dialog with a subtle **HD toggle beside each live-photo placeholder**.
- **Standard is always the default** for new live photos.
- Toggling HD on shows the storage/mobile-data warning only on the user's **first HD selection of that calendar day**.
- After acknowledgement, further HD selections that day do not repeat the warning.
- Turning HD off returns that live-photo slot to Standard.
- Existing saved HD photos display the HD toggle when their member profile is reopened.

## 0.2.3 — Live Photo Quality
- Added Standard/HD processing for Live Photo 1 and Live Photo 2.
- Standard is the recommended lower-storage/lower-data option.
- Added daily HD warning acknowledgement.

## 0.2.2 — Location + Configurable Status
- Added optional member location capture.
- Added configurable member statuses.

## 0.2.1 — Member Photos
- Added camera/gallery photo capture.
- Stored processed photos in ChurchCare private storage.

## 0.2.0 — Member Profiles
- Added member profile/details screen.
- Added three-photo member record.

## 0.3.0 — Field Follow-up / Visits
- Added a local offline member visit record workflow.
- Added visit types: Home Visit, Hospital, Phone Call, Counselling, Other.
- Added visit date/time, member status, summary notes, and care/need flag.
- Added recent visit history to the member profile.
- Added local SQLite `member_visits` table and database migration to version 5.
- Preserved existing member photos, configurable statuses, address/location, and SD/HD photo controls.


## 0.4.0 — Care Management
- Added Care Management for individual members.
- Added care ticket creation with Financial, Medical, Housing, Employment, and Spiritual categories.
- Added description, estimated cost, handling organization, and ticket status.
- Added local ticket history/event tracking.
- Added OPEN, ESCALATED, APPROVED, RESOLVED, and REJECTED workflow states.
- Added local upward escalation event; actual hierarchy routing remains reserved for Phase 4.
- Database upgraded to version 6.

## 0.4.1-fix1
- Fixed SQLite migration block placement in MemberDetailActivity and VisitActivity.
- The care-category seed/migration for database version 7 is now inside the correct onUpgrade methods.
- No functional changes to configurable care categories.


## 0.4.2 - Member profile flow
- Moved Care Management below Field Follow-up / visitation log for a more natural member-care workflow.
- No care ticket data model or functionality changed.

## 0.5.0 — Configurable Church Structure
- Added local Church/Tenant configuration with a generated Parent Join Code.
- Added configurable hierarchy levels with add, rename, and delete controls.
- Added local organization records tied to hierarchy levels.
- Added a Church Structure entry point from the home screen.
- Prepared local parent/child organization fields for the later organization workflow.

## 0.5.1 — Leadership & Delegation + Database Reliability
- Added configurable leadership/delegation assignments for organizations.
- A designated person can be recorded with a role/responsibility and reporting-to person.
- Leadership assignments are separate from the organizational hierarchy; they do not create another hierarchy level.
- Fixed a database initialization flaw where different screens could open the shared SQLite database first and leave required tables unavailable, causing member-save crashes.
- Added a shared schema guard and database version 9 so every screen safely initializes the complete local schema.


## 0.5.7 — Visual Structure Syntax Cleanup
- Fixed the remaining `addOrganization(...)` argument mismatch in the empty-level visual-tree control.
- Reviewed all `addOrganization(...)` call sites in `StructureManagerActivity.java` for the two-argument API.
- Preserved the working member-save/database reliability fix and existing visual-structure behavior.
- Included the original ChurchCare Master Work Sheet with this project archive for continuity.

## 0.6.0 — Pastoral Transfers & Promotions
- Added a dedicated **Pastoral Appointments** screen separate from the church organizational tree.
- Added pastor/overseer records that can have multiple appointments over time.
- Added appointment types: Initial appointment, Transfer, Promotion, and Promotion + Transfer.
- An appointment can move a pastor to another parish, area, zone, or any other configured organization and can simultaneously change the role.
- When a new future/current appointment is recorded, the person's previous current appointment is closed without moving or deleting the organization, members, visits, care records, photos, or other church data.
- Added appointment history so previous assignments remain traceable.
- Preserved the existing Leadership & Delegation system; designated workers remain separate from pastoral appointment history.
- Database upgraded to version 10.

## 0.6.2 — Localized Visual Organization Tree
- Made the visual tree the primary/default structure view.
- Added a remembered **View from this organization** focus so each user can work from their own node/branch while still seeing the reporting path above.
- The focused branch keeps unrelated sibling branches out of the view.
- Same-level children remain side-by-side, with a visible **Add another** action.
- The focused branch now renders descendants recursively through all configured levels.
- Legitimate empty organizations remain visible without being forced to have children.
- Added pinch-to-zoom and horizontal scrolling for wide structures.
- This is a local-focus prototype until real user authentication/authorization can automatically derive the user's permitted organization scope.

## 0.6.3 — Add Organization Crash Fix
- Fixed a crash risk in the Add Organization / Add Church dialog caused by the hierarchy-level spinner being queried before a valid selection was available.
- Added defensive validation for hierarchy level and parent selections before saving.
- Preserved the localized visual tree and existing organizational structure behavior.
- No member, visit, care, photo, pastoral assignment, or delegation data is removed by this fix.

## 0.6.5 — Member Management Compile Fix
- Fixed `MainActivity.java` missing `java.util.ArrayList` import.
- This resolves the compilation errors for `filterStatuses` and the member-filter query arguments in ChurchCare 0.6.4.
- No functional member-management behavior was intentionally changed.

## 0.6.7 — Care Management & Follow-up
- Expanded Care Management into a practical care/follow-up workflow.
- Care tickets can now record an optional responsible pastor/worker.
- Added an optional follow-up date to each care ticket.
- Added a resolution/outcome note when a ticket is marked RESOLVED.
- Member care cards show assignment and scheduled follow-up information when present.
- Ticket details show assignment, follow-up date, and resolution outcome.
- Preserved the existing configurable care categories and ticket event history.
- Database upgraded to version 12 with safe column additions for existing installations.
- Kept the privacy-first visit retention policy unchanged.
