plugins {
    id("com.android.application")
}

android {
    namespace = "com.churchcare.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.churchcare.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 13
        versionName = "0.6.8"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
