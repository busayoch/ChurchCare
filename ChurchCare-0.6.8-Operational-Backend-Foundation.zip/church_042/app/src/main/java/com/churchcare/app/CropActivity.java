package com.churchcare.app;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.FileOutputStream;

public class CropActivity extends Activity {
    private CropView cropView;
    private Uri source;
    private long memberId;
    private int slot;
    private static final int OUTPUT_SIZE = 320;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        source = Uri.parse(getIntent().getStringExtra("source"));
        memberId = getIntent().getLongExtra("member_id", -1);
        slot = getIntent().getIntExtra("slot", 0);
        Bitmap bitmap;
        try { bitmap = BitmapFactory.decodeStream(getContentResolver().openInputStream(source)); }
        catch (Exception e) { bitmap = null; }
        if (bitmap == null) { Toast.makeText(this, "Could not open photo", Toast.LENGTH_SHORT).show(); finish(); return; }

        FrameLayout root = new FrameLayout(this); root.setBackgroundColor(Color.BLACK);
        cropView = new CropView(bitmap); root.addView(cropView, new FrameLayout.LayoutParams(-1,-1));
        LinearLayout controls = new LinearLayout(this); controls.setOrientation(LinearLayout.VERTICAL); controls.setPadding(18,12,18,18); controls.setBackgroundColor(0xCC000000);
        TextView hint = new TextView(this); hint.setText("Move the picture and pinch to zoom. Position the face inside the circle."); hint.setTextColor(Color.WHITE); hint.setTextSize(14); hint.setPadding(4,0,4,10); controls.addView(hint);
        LinearLayout buttons = new LinearLayout(this); buttons.setGravity(android.view.Gravity.END|android.view.Gravity.CENTER_VERTICAL);
        Button cancel = new Button(this); cancel.setText("Cancel"); cancel.setAllCaps(false); cancel.setOnClickListener(v -> finish());
        Button use = new Button(this); use.setText("Use Photo"); use.setAllCaps(false); use.setOnClickListener(v -> saveCrop());
        buttons.addView(cancel); buttons.addView(use); controls.addView(buttons);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1,-2,android.view.Gravity.BOTTOM); root.addView(controls,cp); setContentView(root);
    }

    private void saveCrop() {
        try {
            Bitmap out = cropView.getCroppedBitmap(OUTPUT_SIZE);
            File dir = new File(getFilesDir(), "member_photos"); if (!dir.exists() && !dir.mkdirs()) throw new Exception("storage");
            File f = new File(dir, "member_"+memberId+"_profile_"+System.currentTimeMillis()+".jpg");
            FileOutputStream fos = new FileOutputStream(f); out.compress(Bitmap.CompressFormat.JPEG, 72, fos); fos.close(); out.recycle();
            getIntent().putExtra("result_uri", Uri.fromFile(f).toString()); setResult(RESULT_OK,getIntent()); finish();
        } catch (Exception e) { Toast.makeText(this,"Could not create profile photo",Toast.LENGTH_SHORT).show(); }
    }

    private class CropView extends View {
        Bitmap bitmap; Paint imagePaint = new Paint(Paint.ANTI_ALIAS_FLAG|Paint.FILTER_BITMAP_FLAG); Paint overlay = new Paint(); Matrix matrix = new Matrix(); float scale=1f, minScale=1f, dx=0, dy=0; float lastX,lastY,lastDist; boolean moving, zooming;
        RectF crop = new RectF();
        CropView(Bitmap b){super(CropActivity.this); bitmap=b; overlay.setColor(0x99000000); setBackgroundColor(Color.BLACK);}
        protected void onSizeChanged(int w,int h,int ow,int oh){ fit(w,h); }
        void fit(int w,int h){ float size=Math.min(w,h)*0.68f; minScale=Math.max(size/bitmap.getWidth(),size/bitmap.getHeight()); scale=minScale; dx=w/2f-bitmap.getWidth()*scale/2f; dy=h/2f-bitmap.getHeight()*scale/2f; }
        protected void onDraw(Canvas c){ super.onDraw(c); matrix.reset(); matrix.postScale(scale,scale); matrix.postTranslate(dx,dy); c.drawBitmap(bitmap,matrix,imagePaint); float size=Math.min(getWidth(),getHeight())*0.68f; float l=(getWidth()-size)/2f,t=(getHeight()-size)/2f; crop.set(l,t,l+size,t+size); c.drawRect(0,0,getWidth(),t,overlay); c.drawRect(0,t,l,getHeight()-t,overlay); c.drawRect(l+size,t,getWidth(),getHeight()-t,overlay); c.drawRect(0,t+size,getWidth(),getHeight(),overlay); Paint p=new Paint(Paint.ANTI_ALIAS_FLAG); p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(4); p.setColor(Color.WHITE); c.drawCircle(crop.centerX(),crop.centerY(),size*0.43f,p); }
        public boolean onTouchEvent(MotionEvent e){ int a=e.getActionMasked(); if(a==MotionEvent.ACTION_DOWN){lastX=e.getX();lastY=e.getY();moving=true;zooming=false;return true;} if(a==MotionEvent.ACTION_POINTER_DOWN){lastDist=dist(e);zooming=true;moving=false;return true;} if(a==MotionEvent.ACTION_MOVE){ if(e.getPointerCount()>=2){float d=dist(e);if(lastDist>0){float factor=d/lastDist;scale=Math.max(minScale,Math.min(minScale*4f,scale*factor)); clamp();invalidate();}lastDist=d;} else if(moving){dx+=e.getX()-lastX;dy+=e.getY()-lastY;lastX=e.getX();lastY=e.getY();clamp();invalidate();} return true;} if(a==MotionEvent.ACTION_UP||a==MotionEvent.ACTION_CANCEL){moving=false;zooming=false;return true;} return true; }
        float dist(MotionEvent e){if(e.getPointerCount()<2)return 0;float x=e.getX(0)-e.getX(1),y=e.getY(0)-e.getY(1);return (float)Math.sqrt(x*x+y*y);}
        void clamp(){float size=Math.min(getWidth(),getHeight())*0.68f;float l=(getWidth()-size)/2f,t=(getHeight()-size)/2f;float bw=bitmap.getWidth()*scale,bh=bitmap.getHeight()*scale;if(bw>size){dx=Math.min(l,Math.max(l+size-bw,dx));}else dx=l+(size-bw)/2f;if(bh>size){dy=Math.min(t,Math.max(t+size-bh,dy));}else dy=t+(size-bh)/2f;}
        Bitmap getCroppedBitmap(int outSize){float size=Math.min(getWidth(),getHeight())*0.68f;float l=(getWidth()-size)/2f,t=(getHeight()-size)/2f;float sx=(l-dx)/scale, sy=(t-dy)/scale, sw=size/scale; sx=Math.max(0,Math.min(bitmap.getWidth()-1,sx));sy=Math.max(0,Math.min(bitmap.getHeight()-1,sy));sw=Math.min(sw,bitmap.getWidth()-sx);sw=Math.min(sw,bitmap.getHeight()-sy);Bitmap b=Bitmap.createBitmap(bitmap,(int)sx,(int)sy,Math.max(1,(int)sw),Math.max(1,(int)sw));return Bitmap.createScaledBitmap(b,outSize,outSize,true);}
    }
}
