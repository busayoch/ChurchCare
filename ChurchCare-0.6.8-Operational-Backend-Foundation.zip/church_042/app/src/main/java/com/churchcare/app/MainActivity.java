package com.churchcare.app;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private MemberDb db;
    private LinearLayout memberList;
    private TextView emptyText;
    private EditText searchBox;
    private Spinner statusFilter;
    private ArrayList<String> filterStatuses = new ArrayList<>();

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new MemberDb();
        memberList = findViewById(R.id.memberList);
        emptyText = findViewById(R.id.emptyText);
        findViewById(R.id.addMemberButton).setOnClickListener(v -> showAddMember());
        setupMemberFilters();
        findViewById(R.id.structureButton).setOnClickListener(v -> startActivity(new Intent(this, StructureManagerActivity.class)));
        refreshMembers();
    }

    @Override protected void onResume() {
        super.onResume();
        if (memberList != null) refreshMembers();
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable cardBackground() {
        GradientDrawable d = new GradientDrawable();
        d.setColor(Color.WHITE);
        d.setCornerRadius(dp(14));
        d.setStroke(dp(1), 0xFFE4E4E4);
        return d;
    }

    private void showAddMember() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), 0, dp(20), 0);

        EditText name = new EditText(this);
        name.setHint("Full name *");
        name.setSingleLine(true);
        EditText phone = new EditText(this);
        phone.setHint("Phone number (optional)");
        phone.setSingleLine(true);
        phone.setInputType(android.text.InputType.TYPE_CLASS_PHONE);
        box.addView(name, new LinearLayout.LayoutParams(-1, -2));
        box.addView(phone, new LinearLayout.LayoutParams(-1, -2));

        new AlertDialog.Builder(this).setTitle("Add Member")
                .setMessage("You can add photos and more details after saving the member.")
                .setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Save", (d, w) -> saveMember(name.getText().toString().trim(), phone.getText().toString().trim()))
                .show();
    }

    private void saveMember(String name, String phone) {
        if (name.isEmpty()) {
            Toast.makeText(this, "Please enter the member's name", Toast.LENGTH_SHORT).show();
            return;
        }
        ContentValues values = new ContentValues();
        values.put("full_name", name);
        if (!phone.isEmpty()) values.put("phone_number", phone);
        values.put("created_at", System.currentTimeMillis());
        long id = db.getWritableDatabase().insertOrThrow("members", null, values);
        Toast.makeText(this, "Member saved", Toast.LENGTH_SHORT).show();
        refreshMembers();
        Intent intent = new Intent(this, MemberDetailActivity.class);
        intent.putExtra("member_id", id);
        startActivity(intent);
    }

    private void setupMemberFilters() {
        searchBox = findViewById(R.id.memberSearch);
        statusFilter = findViewById(R.id.statusFilter);
        loadFilterStatuses();
        searchBox.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s,int st,int c,int a){}
            public void onTextChanged(CharSequence s,int st,int b,int c){ refreshMembers(); }
            public void afterTextChanged(Editable e){}
        });
        statusFilter.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> p){}
            public void onItemSelected(android.widget.AdapterView<?> p, View v,int pos,long id){ refreshMembers(); }
        });
    }

    private void loadFilterStatuses() {
        filterStatuses.clear(); filterStatuses.add("All statuses");
        Cursor c=db.getReadableDatabase().query("statuses",new String[]{"name"},null,null,null,null,"sort_order ASC,status_id ASC");
        try { while(c.moveToNext()) filterStatuses.add(c.getString(0)); } finally { c.close(); }
        statusFilter.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,filterStatuses));
    }

    private void refreshMembers() {
        if (memberList == null) return;
        memberList.removeAllViews();
        String q = searchBox == null ? "" : searchBox.getText().toString().trim();
        String selected = statusFilter == null || statusFilter.getSelectedItem()==null ? "All statuses" : statusFilter.getSelectedItem().toString();
        StringBuilder where=new StringBuilder(); ArrayList<String> args=new ArrayList<>();
        if(!q.isEmpty()){ where.append("(full_name LIKE ? OR phone_number LIKE ?)"); String like="%"+q+"%"; args.add(like); args.add(like); }
        if(!"All statuses".equals(selected)){ if(where.length()>0)where.append(" AND "); where.append("status=?"); args.add(selected); }
        Cursor c = db.getReadableDatabase().query("members",
                new String[]{"member_id", "full_name", "phone_number", "photo1_uri", "status"},
                where.length()==0?null:where.toString(), args.toArray(new String[0]), null, null, "full_name COLLATE NOCASE ASC");
        boolean any = false;
        try {
            while (c.moveToNext()) {
                any = true;
                final long id = c.getLong(0);
                String name = c.getString(1);
                String phone = c.isNull(2) ? "" : c.getString(2);
                String photo = c.isNull(3) ? "" : c.getString(3);
                String memberStatus = c.isNull(4) ? "Active" : c.getString(4);

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(12), dp(12), dp(12), dp(12));
                row.setBackground(cardBackground());
                row.setElevation(dp(3));
                row.setClickable(true);
                row.setOnClickListener(v -> startMember(id));

                ImageView avatar = new ImageView(this);
                int avatarSize = dp(64);
                avatar.setLayoutParams(new LinearLayout.LayoutParams(avatarSize, avatarSize));
                avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);
                GradientDrawable circle = new GradientDrawable();
                circle.setShape(GradientDrawable.OVAL);
                circle.setColor(0xFFE5E8E6);
                avatar.setBackground(circle);
                avatar.setClipToOutline(true);
                if (!photo.isEmpty()) {
                    try { avatar.setImageURI(Uri.parse(photo)); } catch (Exception ignored) { }
                }

                LinearLayout textBox = new LinearLayout(this);
                textBox.setOrientation(LinearLayout.VERTICAL);
                textBox.setPadding(dp(14), 0, dp(8), 0);
                textBox.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));

                TextView title = new TextView(this);
                title.setText(name);
                title.setTextSize(18);
                title.setTextColor(Color.BLACK);
                title.setTypeface(null, android.graphics.Typeface.BOLD);
                textBox.addView(title);

                TextView sub = new TextView(this);
                sub.setText((phone.isEmpty() ? "Phone not provided" : phone) + "  •  " + memberStatus);
                sub.setTextSize(15);
                sub.setTextColor(0xFF555555);
                sub.setPadding(0, dp(4), 0, 0);
                textBox.addView(sub);

                TextView arrow = new TextView(this);
                arrow.setText("›");
                arrow.setTextSize(34);
                arrow.setTextColor(0xFF666666);
                arrow.setGravity(Gravity.CENTER);

                row.addView(avatar);
                row.addView(textBox);
                row.addView(arrow, new LinearLayout.LayoutParams(dp(32), dp(64)));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
                lp.setMargins(0, 0, 0, dp(12));
                memberList.addView(row, lp);
            }
        } finally { c.close(); }
        if (any) emptyText.setVisibility(View.GONE);
        else { emptyText.setVisibility(View.VISIBLE); emptyText.setText(q.isEmpty() && "All statuses".equals(selected) ? "No members saved yet. Add your first member below." : "No members match the current search/filter."); }
    }

    private void startMember(long id) {
        Intent intent = new Intent(this, MemberDetailActivity.class);
        intent.putExtra("member_id", id);
        startActivity(intent);
    }

    private class MemberDb extends SQLiteOpenHelper {
        MemberDb() { super(MainActivity.this, "churchcare.db", null, ChurchCareDb.VERSION); }
        @Override public void onCreate(SQLiteDatabase db) { ChurchCareDb.ensureAll(db); }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { ChurchCareDb.ensureAll(db); }
    }
}
