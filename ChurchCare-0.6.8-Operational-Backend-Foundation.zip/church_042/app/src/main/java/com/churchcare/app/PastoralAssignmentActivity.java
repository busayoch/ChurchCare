package com.churchcare.app;

import android.app.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.*;
import java.util.*;

/** Manages pastoral appointments independently of the church structure. */
public class PastoralAssignmentActivity extends Activity {
    private SQLiteOpenHelper db; private LinearLayout list;
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    private TextView t(String s,float z,int c){TextView v=new TextView(this);v.setText(s);v.setTextSize(z);v.setTextColor(c);return v;}
    private String date(long ms){return new SimpleDateFormat("dd MMM yyyy",Locale.US).format(new Date(ms));}
    private long parseDate(String s){try{return new SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(s).getTime();}catch(Exception e){return -1;}}

    @Override public void onCreate(Bundle b){super.onCreate(b);db=new H();build();refresh();}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xfff7f8f6);
        TextView h=t("‹   Pastoral Appointments",21,Color.WHITE);h.setTypeface(null,1);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(10),0,0,0);h.setBackgroundColor(0xff1b5e20);h.setOnClickListener(v->finish());root.addView(h,new LinearLayout.LayoutParams(-1,dp(64)));
        TextView info=t("Record pastor/overseer appointments separately from the church tree. A transfer, promotion, or promotion + transfer changes the person's assignment, not the church's members or history.",14,0xff555555);info.setPadding(dp(14),dp(12),dp(14),dp(8));root.addView(info);
        ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(14),dp(6),dp(14),dp(24));sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        Button add=new Button(this);add.setText("＋ Record new appointment");add.setOnClickListener(v->addAppointment());root.addView(add);setContentView(root);
    }
    private void refresh(){list.removeAllViews();
        Cursor c=db.getReadableDatabase().rawQuery("SELECT a.appointment_id,p.full_name,o.name,a.role_name,a.start_at,a.end_at,a.change_type FROM pastoral_appointments a JOIN pastors p ON p.person_id=a.person_id JOIN organizations o ON o.organization_id=a.organization_id ORDER BY CASE WHEN a.end_at IS NULL THEN 0 ELSE 1 END,a.start_at DESC",null);
        try{boolean any=false;while(c.moveToNext()){any=true;long id=c.getLong(0);String person=c.getString(1),org=c.getString(2),role=c.getString(3);long start=c.getLong(4);String end=c.isNull(5)?"Present":date(c.getLong(5));String type=c.getString(6);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(10),dp(8),dp(8));box.setBackgroundColor(Color.WHITE);
            TextView title=t(person+" — "+role,17,Color.BLACK);title.setTypeface(null,1);box.addView(title);box.addView(t(org+"  •  "+type,14,0xff555555));box.addView(t(date(start)+" – "+end,13,0xff777777));
            Button hist=new Button(this);hist.setText("View history for "+person);hist.setOnClickListener(v->showHistory(cPersonId(id)));box.addView(hist);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(8));list.addView(box,lp);
        }if(!any)list.addView(t("No pastoral appointments recorded yet.",15,0xff777777));}finally{c.close();}}
    private long cPersonId(long appointmentId){Cursor c=db.getReadableDatabase().rawQuery("SELECT person_id FROM pastoral_appointments WHERE appointment_id=?",new String[]{""+appointmentId});try{return c.moveToFirst()?c.getLong(0):-1;}finally{c.close();}}
    private void showHistory(long personId){Cursor c=db.getReadableDatabase().rawQuery("SELECT p.full_name,o.name,a.role_name,a.start_at,a.end_at,a.change_type,a.notes FROM pastoral_appointments a JOIN pastors p ON p.person_id=a.person_id JOIN organizations o ON o.organization_id=a.organization_id WHERE p.person_id=? ORDER BY a.start_at DESC",new String[]{""+personId});StringBuilder b=new StringBuilder();String name="";try{while(c.moveToNext()){name=c.getString(0);b.append(c.getString(1)).append("\n").append(c.getString(2)).append("\n").append(date(c.getLong(3))).append(" – ").append(c.isNull(4)?"Present":date(c.getLong(4))).append("\n").append(c.getString(5));if(!c.isNull(6)&&!c.getString(6).trim().isEmpty())b.append("\nNote: ").append(c.getString(6));b.append("\n\n");}}finally{c.close();}new AlertDialog.Builder(this).setTitle(name+" — Appointment History").setMessage(b.toString()).setPositiveButton("Close",null).show();}

    private void addAppointment(){
        SQLiteDatabase s=db.getReadableDatabase();ArrayList<Long> pids=new ArrayList<>();ArrayList<String> pnames=new ArrayList<>();Cursor pc=s.rawQuery("SELECT person_id,full_name FROM pastors ORDER BY full_name",null);try{while(pc.moveToNext()){pids.add(pc.getLong(0));pnames.add(pc.getString(1));}}finally{pc.close();}
        ArrayList<Long> oids=new ArrayList<>();ArrayList<String> onames=new ArrayList<>();Cursor oc=s.rawQuery("SELECT organization_id,name FROM organizations ORDER BY name",null);try{while(oc.moveToNext()){oids.add(oc.getLong(0));onames.add(oc.getString(1));}}finally{oc.close();}
        if(onames.isEmpty()){Toast.makeText(this,"Create an organization first",Toast.LENGTH_SHORT).show();return;}
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),0,dp(18),0);
        Spinner person=new Spinner(this);ArrayList<String> pn=new ArrayList<>(pnames);pn.add("＋ Add new pastor/overseer");person.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,pn));box.addView(label("Pastor / overseer"));box.addView(person);
        EditText newPerson=new EditText(this);newPerson.setHint("New person's full name");newPerson.setVisibility(pnames.isEmpty()?View.VISIBLE:View.GONE);box.addView(newPerson);
        person.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){newPerson.setVisibility(pos==pnames.size()?View.VISIBLE:View.GONE);}});
        Spinner org=new Spinner(this);org.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,onames));box.addView(label("New assignment / church"));box.addView(org);
        EditText role=new EditText(this);role.setHint("Role / appointment (e.g. Parish Pastor, Area Pastor)");box.addView(label("Role"));box.addView(role);
        Spinner type=new Spinner(this);String[] types={"Initial appointment","Transfer","Promotion","Promotion + Transfer"};type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types));box.addView(label("Change type"));box.addView(type);
        EditText when=new EditText(this);when.setHint("Effective date: YYYY-MM-DD");when.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));box.addView(label("Effective date"));box.addView(when);
        EditText note=new EditText(this);note.setHint("Optional note");note.setMinLines(2);box.addView(label("Note"));box.addView(note);
        new AlertDialog.Builder(this).setTitle("Record pastoral appointment").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->saveAppointment(person,pids,pnames,newPerson,org,oids,role,type,when,note)).show();
    }
    private TextView label(String s){TextView v=t(s,12,0xff666666);v.setPadding(0,dp(8),0,0);return v;}
    private void saveAppointment(Spinner person,ArrayList<Long> pids,ArrayList<String> pnames,EditText newPerson,Spinner org,ArrayList<Long> oids,EditText role,Spinner type,EditText when,EditText note){
        long effective=parseDate(when.getText().toString().trim());String rn=role.getText().toString().trim();if(effective<0||rn.isEmpty()){Toast.makeText(this,"Enter a valid date and role",Toast.LENGTH_SHORT).show();return;}
        SQLiteDatabase s=db.getWritableDatabase();long pid;if(person.getSelectedItemPosition()==pnames.size()){String n=newPerson.getText().toString().trim();if(n.isEmpty()){Toast.makeText(this,"Enter the person's name",Toast.LENGTH_SHORT).show();return;}ContentValues p=new ContentValues();p.put("full_name",n);p.put("created_at",System.currentTimeMillis());pid=s.insert("pastors",null,p);}else pid=pids.get(person.getSelectedItemPosition());
        if(pid==-1){Toast.makeText(this,"Could not create person",Toast.LENGTH_SHORT).show();return;}
        // Close the previous current appointment for this person. The church/node itself is untouched.
        ContentValues end=new ContentValues();end.put("end_at",effective-1);s.update("pastoral_appointments",end,"person_id=? AND end_at IS NULL AND start_at<?",new String[]{""+pid,""+effective});
        ContentValues a=new ContentValues();a.put("person_id",pid);a.put("organization_id",oids.get(org.getSelectedItemPosition()));a.put("role_name",rn);a.put("start_at",effective);a.put("change_type",type.getSelectedItem().toString());a.put("notes",note.getText().toString().trim());a.put("created_at",System.currentTimeMillis());s.insert("pastoral_appointments",null,a);refresh();
    }
    class H extends SQLiteOpenHelper{H(){super(PastoralAssignmentActivity.this,"churchcare.db",null,ChurchCareDb.VERSION);}public void onCreate(SQLiteDatabase d){ChurchCareDb.ensureAll(d);}public void onUpgrade(SQLiteDatabase d,int a,int b){ChurchCareDb.ensureAll(d);}}
}
