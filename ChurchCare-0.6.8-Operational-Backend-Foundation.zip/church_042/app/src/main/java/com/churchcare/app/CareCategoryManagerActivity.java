package com.churchcare.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

public class CareCategoryManagerActivity extends AppCompatActivity {
    private CategoryDb db; private LinearLayout list;
    private int dp(int v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);db=new CategoryDb();build();refresh();}
    private void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFFF7F8F6);
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(10),dp(10),dp(14),dp(10));h.setBackgroundColor(0xFF1B5E20);
        TextView back=text("‹",42,Color.WHITE);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());h.addView(back,new LinearLayout.LayoutParams(dp(48),dp(58)));
        TextView title=text("Care Categories",21,Color.WHITE);title.setTypeface(null,Typeface.BOLD);h.addView(title,new LinearLayout.LayoutParams(0,-2,1));root.addView(h);
        LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(16),dp(8),dp(16),dp(4));TextView add=text("+ Add category",16,0xFF6B4EAA);add.setTypeface(null,Typeface.BOLD);add.setGravity(Gravity.CENTER_VERTICAL);add.setOnClickListener(v->addCategory());bar.addView(add,new LinearLayout.LayoutParams(-1,dp(50)));root.addView(bar);
        TextView hint=text("These are your church's care categories. You can rename, add, or delete them.",13,0xFF666666);hint.setPadding(dp(16),dp(2),dp(16),dp(10));root.addView(hint);
        ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(16),0,dp(16),dp(24));sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    private void refresh(){list.removeAllViews();Cursor c=db.getReadableDatabase().query("care_categories",null,null,null,null,null,"sort_order ASC,name ASC");try{while(c.moveToNext()){long id=c.getLong(c.getColumnIndexOrThrow("category_id"));String name=c.getString(c.getColumnIndexOrThrow("name"));boolean enabled=c.getInt(c.getColumnIndexOrThrow("enabled"))!=0;LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.setPadding(dp(14),dp(10),dp(8),dp(10));row.setBackgroundColor(Color.WHITE);TextView n=text(name+(enabled?"":" (disabled)"),16,0xFF222222);n.setTypeface(null,Typeface.BOLD);row.addView(n,new LinearLayout.LayoutParams(0,dp(54),1));TextView edit=text("Edit",14,0xFF6B4EAA);edit.setGravity(Gravity.CENTER);edit.setOnClickListener(v->editCategory(id,name));row.addView(edit,new LinearLayout.LayoutParams(dp(58),dp(54)));TextView del=text("Delete",14,0xFFB00020);del.setGravity(Gravity.CENTER);del.setOnClickListener(v->deleteCategory(id,name));row.addView(del,new LinearLayout.LayoutParams(dp(68),dp(54)));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(8));list.addView(row,lp);}}finally{c.close();}}
    private void addCategory(){EditText e=new EditText(this);e.setHint("Category name");new AlertDialog.Builder(this).setTitle("Add care category").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;SQLiteDatabase s=db.getWritableDatabase();ContentValues v=new ContentValues();v.put("name",n);v.put("sort_order",nextOrder(s));v.put("enabled",1);long r=s.insertWithOnConflict("care_categories",null,v,SQLiteDatabase.CONFLICT_IGNORE);if(r==-1)Toast.makeText(this,"That category already exists",Toast.LENGTH_SHORT).show();else{refresh();Toast.makeText(this,"Category added",Toast.LENGTH_SHORT).show();}}).show();}
    private int nextOrder(SQLiteDatabase s){Cursor c=s.rawQuery("SELECT COALESCE(MAX(sort_order),0)+1 FROM care_categories",null);try{return c.moveToFirst()?c.getInt(0):1;}finally{c.close();}}
    private void editCategory(long id,String old){EditText e=new EditText(this);e.setText(old);e.setSelectAllOnFocus(true);new AlertDialog.Builder(this).setTitle("Rename care category").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;SQLiteDatabase s=db.getWritableDatabase();ContentValues v=new ContentValues();v.put("name",n);int changed=s.update("care_categories",v,"category_id=?",new String[]{String.valueOf(id)});if(changed==0){Toast.makeText(this,"Category not found",Toast.LENGTH_SHORT).show();return;}ContentValues t=new ContentValues();t.put("category",n);s.update("care_tickets",t,"category=?",new String[]{old});refresh();Toast.makeText(this,"Category renamed",Toast.LENGTH_SHORT).show();}).show();}
    private void deleteCategory(long id,String name){SQLiteDatabase s=db.getReadableDatabase();Cursor c=s.rawQuery("SELECT COUNT(*) FROM care_tickets WHERE category=?",new String[]{name});int count=0;try{if(c.moveToFirst())count=c.getInt(0);}finally{c.close();}if(count>0){new AlertDialog.Builder(this).setTitle("Category is in use").setMessage("This category is used by "+count+" existing care ticket(s), so it cannot be deleted without losing their category history. Rename it instead.").setPositiveButton("OK",null).show();return;}new AlertDialog.Builder(this).setTitle("Delete category?").setMessage("Delete \""+name+"\" from this church's care category list?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.getWritableDatabase().delete("care_categories","category_id=?",new String[]{String.valueOf(id)});refresh();Toast.makeText(this,"Category deleted",Toast.LENGTH_SHORT).show();}).show();}

    private class CategoryDb extends SQLiteOpenHelper {
        CategoryDb(){super(CareCategoryManagerActivity.this,"churchcare.db",null,ChurchCareDb.VERSION);}
        public void onCreate(SQLiteDatabase d){ChurchCareDb.ensureAll(d);}
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){ChurchCareDb.ensureAll(d);}
    }
}
