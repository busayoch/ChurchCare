package com.churchcare.app;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.FileProvider;

public class MemberDetailActivity extends AppCompatActivity {
    private long memberId;
    private MemberDb db;
    private EditText name, phone, dob, address, notes;
    private TextView locationValue;
    private Double latitude, longitude;
    private String locationSource = "";
    private Spinner status;
    private ImageView[] photos = new ImageView[3];
    private String[] photoUris = new String[]{"", "", ""};
    private String[] photoQuality = new String[]{"profile", "standard", "standard"};
    private SwitchCompat[] hdSwitches = new SwitchCompat[3];
    private boolean loadingMember = false;
    private int pendingPhoto = -1;
    private static final int REQUEST_GALLERY = 1001;
    private static final int REQUEST_CAMERA = 1002;
    private static final int REQUEST_CROP = 1003;
    private File cameraTempFile;
    private Uri pendingSourceUri;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        memberId = getIntent().getLongExtra("member_id", -1);
        if (memberId < 0) { finish(); return; }
        db = new MemberDb();
        buildUi();
        loadMember();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, float size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private GradientDrawable bg(int color, int radius) { GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d; }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFFF7F8F6);
        LinearLayout header = new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(10), dp(10), dp(14), dp(10)); header.setBackgroundColor(0xFF1B5E20);
        TextView back = text("‹", 42, Color.WHITE); back.setGravity(Gravity.CENTER); back.setOnClickListener(v -> finish());
        header.addView(back, new LinearLayout.LayoutParams(dp(48), dp(58)));
        TextView title = text("Member Details", 22, Color.WHITE); title.setTypeface(null, Typeface.BOLD); header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView save = text("Save", 16, Color.WHITE); save.setTypeface(null, Typeface.BOLD); save.setPadding(dp(12), 0, 0, 0); save.setOnClickListener(v -> saveMember()); header.addView(save);
        root.addView(header);

        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(content);

        LinearLayout profileCard = card();
        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(4), dp(4), dp(4), dp(8));
        photos[0] = makePhoto(dp(128));
        photos[0].setOnClickListener(v -> choosePhoto(0));
        top.addView(photos[0], new LinearLayout.LayoutParams(dp(128), dp(128)));
        LinearLayout basic = new LinearLayout(this); basic.setOrientation(LinearLayout.VERTICAL); basic.setPadding(dp(14), 0, 0, 0);
        name = field("Full name *"); phone = field("Phone number");
        basic.addView(name); basic.addView(phone);
        top.addView(basic, new LinearLayout.LayoutParams(0, -2, 1)); profileCard.addView(top);
        TextView hint = text("Profile: face crop • Photos 2–3: camera or gallery, Standard or HD", 13, 0xFF666666); hint.setPadding(dp(4), 0, dp(4), dp(8)); profileCard.addView(hint);
        LinearLayout gallery = new LinearLayout(this); gallery.setGravity(Gravity.CENTER); gallery.setPadding(dp(4), dp(4), dp(4), dp(8));
        for (int i = 1; i < 3; i++) {
            final int index = i;
            LinearLayout slot = new LinearLayout(this); slot.setOrientation(LinearLayout.VERTICAL); slot.setGravity(Gravity.CENTER);
            photos[i] = makePhoto(dp(82)); photos[i].setOnClickListener(v -> choosePhoto(index));
            LinearLayout.LayoutParams imageLp = new LinearLayout.LayoutParams(dp(82), dp(82));
            slot.addView(photos[i], imageLp);

            TextView photoLabel = text(i == 1 ? "Live photo 1" : "Live photo 2", 12, 0xFF555555);
            photoLabel.setGravity(Gravity.CENTER);
            slot.addView(photoLabel, new LinearLayout.LayoutParams(-1, dp(28)));

            // Clear quality control: SD is on the left (the default/off position), HD on the right.
            LinearLayout qualityRow = new LinearLayout(this);
            qualityRow.setGravity(Gravity.CENTER);
            TextView sdLabel = text("SD", 11, 0xFF555555);
            sdLabel.setGravity(Gravity.CENTER);
            TextView hdLabel = text("HD", 11, 0xFF555555);
            hdLabel.setGravity(Gravity.CENTER);
            hdSwitches[i] = new SwitchCompat(this);
            hdSwitches[i].setText("");
            hdSwitches[i].setShowText(false);
            hdSwitches[i].setChecked(false);
            hdSwitches[i].setContentDescription("Photo quality: SD off, HD on");
            hdSwitches[i].setOnCheckedChangeListener((button, checked) -> {
                if (loadingMember) return;
                if (checked) confirmHdToggle(index, button);
                else photoQuality[index] = "standard";
            });
            LinearLayout.LayoutParams qLabel = new LinearLayout.LayoutParams(dp(24), dp(36));
            LinearLayout.LayoutParams qSwitch = new LinearLayout.LayoutParams(dp(50), dp(36));
            qualityRow.addView(sdLabel, qLabel);
            qualityRow.addView(hdSwitches[i], qSwitch);
            qualityRow.addView(hdLabel, qLabel);
            slot.addView(qualityRow);
            LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(dp(132), -2); sp.setMargins(dp(3), 0, dp(3), 0); gallery.addView(slot, sp);
        }
        profileCard.addView(gallery);
        content.addView(profileCard, marginBottom());

        content.addView(sectionTitle("About"));
        LinearLayout about = card();
        dob = field("Date of birth"); dob.setFocusable(false); dob.setOnClickListener(v -> pickDate()); about.addView(labelField("Date of birth", dob));
        address = field("Address"); about.addView(labelField("Address", address));
        status = new Spinner(this); loadStatuses(); about.addView(labelField("Status", status));
        TextView manageStatus = text("Manage status options", 14, 0xFF6B4EAA); manageStatus.setPadding(dp(4), dp(4), dp(4), dp(8)); manageStatus.setOnClickListener(v -> startActivity(new Intent(this, StatusManagerActivity.class))); about.addView(manageStatus);
        LinearLayout locBox = new LinearLayout(this); locBox.setOrientation(LinearLayout.VERTICAL);
        locBox.addView(text("Location (optional)", 12, 0xFF666666));
        locationValue = text("No location recorded", 15, 0xFF444444); locationValue.setPadding(dp(4), dp(7), dp(4), dp(7)); locBox.addView(locationValue);
        LinearLayout locButtons = new LinearLayout(this); locButtons.setGravity(Gravity.CENTER_VERTICAL);
        TextView capture = text("Capture current location", 14, 0xFF6B4EAA); capture.setGravity(Gravity.CENTER); capture.setOnClickListener(v -> captureLocation()); locButtons.addView(capture, new LinearLayout.LayoutParams(0, dp(48), 1));
        TextView maps = text("Open in Google Maps", 14, 0xFF6B4EAA); maps.setGravity(Gravity.CENTER); maps.setOnClickListener(v -> openInMaps()); locButtons.addView(maps, new LinearLayout.LayoutParams(0, dp(48), 1)); locBox.addView(locButtons); about.addView(locBox);
        notes = field("Private notes"); notes.setMinLines(3); notes.setGravity(Gravity.TOP); about.addView(labelField("Notes", notes));
        content.addView(about, marginBottom());

        content.addView(sectionTitle("Field Follow-up"));
        LinearLayout follow = card();
        TextView recordVisit = text("Record a Visit", 16, 0xFF6B4EAA);
        recordVisit.setTypeface(null, Typeface.BOLD);
        recordVisit.setGravity(Gravity.CENTER_VERTICAL);
        recordVisit.setPadding(dp(6), dp(4), dp(6), dp(4));
        recordVisit.setOnClickListener(v -> startActivity(new Intent(this, VisitActivity.class).putExtra("member_id", memberId)));
        follow.addView(recordVisit, new LinearLayout.LayoutParams(-1, dp(52)));
        TextView visitHistory = text("Recent visit history (last 5)", 14, 0xFF555555);
        visitHistory.setPadding(dp(6), dp(2), dp(6), dp(6));
        follow.addView(visitHistory);
        LinearLayout historyBox = new LinearLayout(this);
        historyBox.setOrientation(LinearLayout.VERTICAL);
        follow.addView(historyBox);
        loadVisitHistory(historyBox);
        content.addView(follow, marginBottom());

        LinearLayout care = card();
        TextView careTitle = text("Care Management", 18, 0xFF222222); careTitle.setTypeface(null, Typeface.BOLD); careTitle.setPadding(dp(6),dp(4),dp(6),dp(8)); care.addView(careTitle);
        TextView careBtn = text("Care needs & tickets", 16, 0xFF6B4EAA); careBtn.setPadding(dp(6),dp(6),dp(6),dp(10)); careBtn.setOnClickListener(v -> startActivity(new Intent(this, CareActivity.class).putExtra("member_id", memberId))); care.addView(careBtn, new LinearLayout.LayoutParams(-1,dp(50)));
        content.addView(care, marginBottom());

        content.addView(sectionTitle("Member Summary"));
        LinearLayout summary = card();
        SQLiteDatabase summaryDb=db.getReadableDatabase();
        int visitCount=0, careCount=0; long memberSince=0;
        Cursor sc=summaryDb.rawQuery("SELECT (SELECT COUNT(*) FROM member_visits WHERE member_id=?),(SELECT COUNT(*) FROM care_tickets WHERE member_id=?),created_at FROM members WHERE member_id=?",new String[]{String.valueOf(memberId),String.valueOf(memberId),String.valueOf(memberId)});
        try{if(sc.moveToFirst()){visitCount=sc.getInt(0);careCount=sc.getInt(1);memberSince=sc.getLong(2);}}finally{sc.close();}
        summary.addView(summaryRow("Total Visits", String.valueOf(visitCount)));
        summary.addView(summaryRow("Care Tickets", String.valueOf(careCount)));
        summary.addView(summaryRow("Member since", memberSince>0?DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(memberSince)):""));
        content.addView(summary, marginBottom());

        content.addView(sectionTitle("Recent Activity"));
        LinearLayout activity = card(); TextView activityText = text("Member added\n" + DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date()), 15, 0xFF333333); activityText.setPadding(dp(4), dp(4), dp(4), dp(4)); activity.addView(activityText); content.addView(activity, marginBottom());

        Button delete = new Button(this); delete.setText("Delete Member"); delete.setTextColor(0xFFB00020); delete.setAllCaps(false); delete.setOnClickListener(v -> confirmDelete()); content.addView(delete);

        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1)); setContentView(root);
    }

    private LinearLayout card() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(12), dp(12), dp(12), dp(12)); l.setBackground(bg(Color.WHITE, 14)); l.setElevation(dp(2)); return l; }
    private LinearLayout.LayoutParams marginBottom() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, -2); p.setMargins(0, 0, 0, dp(12)); return p; }
    private TextView sectionTitle(String s) { TextView t = text(s, 21, 0xFF6B4EAA); t.setTypeface(null, Typeface.BOLD); t.setPadding(dp(4), dp(6), dp(4), dp(8)); return t; }
    private EditText field(String hint) { EditText e = new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(false); e.setPadding(dp(4), dp(6), dp(4), dp(6)); return e; }
    private LinearLayout labelField(String label, View v) { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); TextView t = text(label, 12, 0xFF666666); l.addView(t); l.addView(v); return l; }
    private void loadVisitHistory(LinearLayout box) {
        Cursor c = db.getReadableDatabase().query("member_visits",
                new String[]{"visit_date","visit_type","member_status","notes","care_need"},
                "member_id=?", new String[]{String.valueOf(memberId)}, null, null, "visit_date DESC", "5");
        try {
            if (!c.moveToFirst()) {
                TextView none = text("No visits recorded yet.", 14, 0xFF777777);
                none.setPadding(dp(6), dp(4), dp(6), dp(8));
                box.addView(none);
                return;
            }
            do {
                long date = c.getLong(0);
                String type = c.getString(1);
                String st = c.isNull(2) ? "" : c.getString(2);
                String note = c.isNull(3) ? "" : c.getString(3);
                int care = c.getInt(4);
                TextView row = text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(new Date(date)) + " • " + type + (st.isEmpty()?"":" • "+st) + (care==1?" • Care need":"") + (note.isEmpty()?"":"\n"+note), 14, 0xFF333333);
                row.setPadding(dp(6), dp(7), dp(6), dp(7));
                box.addView(row);
            } while (c.moveToNext());
        } finally { c.close(); }
    }

    private LinearLayout summaryRow(String label, String value) { LinearLayout l = new LinearLayout(this); l.setGravity(Gravity.CENTER_VERTICAL); TextView a = text(label, 15, 0xFF333333); TextView b = text(value, 15, 0xFF333333); l.addView(a, new LinearLayout.LayoutParams(0, dp(42), 1)); l.addView(b); return l; }

    private ImageView makePhoto(int size) { ImageView iv = new ImageView(this); iv.setScaleType(ImageView.ScaleType.CENTER_CROP); GradientDrawable d = new GradientDrawable(); d.setShape(GradientDrawable.OVAL); d.setColor(0xFFE5E8E6); d.setStroke(dp(1), 0xFFD0D0D0); iv.setBackground(d); iv.setClipToOutline(true); return iv; }

    private void loadMember() {
        loadingMember = true;
        Cursor c = db.getReadableDatabase().query("members", null, "member_id=?", new String[]{String.valueOf(memberId)}, null, null, null);
        try {
            if (c.moveToFirst()) {
                name.setText(c.getString(c.getColumnIndexOrThrow("full_name")));
                String p = c.getString(c.getColumnIndexOrThrow("phone_number")); if (p != null) phone.setText(p);
                String d = c.getString(c.getColumnIndexOrThrow("date_of_birth")); if (d != null) dob.setText(d);
                String a = c.getString(c.getColumnIndexOrThrow("address")); if (a != null) address.setText(a);
                String n = c.getString(c.getColumnIndexOrThrow("notes")); if (n != null) notes.setText(n);
                String st = c.getString(c.getColumnIndexOrThrow("status")); if (st != null) { for (int i=0;i<status.getCount();i++) if (status.getItemAtPosition(i).toString().equals(st)) status.setSelection(i); }
                int latCol=c.getColumnIndex("latitude"), lonCol=c.getColumnIndex("longitude"), srcCol=c.getColumnIndex("location_source"); if(latCol>=0&&!c.isNull(latCol)&&lonCol>=0&&!c.isNull(lonCol)){latitude=c.getDouble(latCol);longitude=c.getDouble(lonCol);locationSource=srcCol>=0&&!c.isNull(srcCol)?c.getString(srcCol):"";updateLocationText();}
                for (int i=0;i<3;i++) { String key = "photo"+(i+1)+"_uri"; int col=c.getColumnIndexOrThrow(key); photoUris[i]=c.isNull(col)?"":c.getString(col); setPhotoImage(i); }
                int q2=c.getColumnIndex("photo2_quality"), q3=c.getColumnIndex("photo3_quality");
                if(q2>=0 && !c.isNull(q2)) photoQuality[1]=c.getString(q2);
                if(q3>=0 && !c.isNull(q3)) photoQuality[2]=c.getString(q3);
                if (hdSwitches[1] != null) hdSwitches[1].setChecked("hd".equals(photoQuality[1]));
                if (hdSwitches[2] != null) hdSwitches[2].setChecked("hd".equals(photoQuality[2]));
            }
        } finally { c.close(); loadingMember = false; }
    }

    private void setPhotoImage(int index) { if (photos[index] == null) return; if (photoUris[index] != null && !photoUris[index].isEmpty()) { try { photos[index].setImageURI(Uri.parse(photoUris[index])); } catch (Exception ignored) {} } else { photos[index].setImageDrawable(null); } }

    private void loadStatuses(){ArrayList<String> names=new ArrayList<>();Cursor c=db.getReadableDatabase().query("statuses",new String[]{"name"},null,null,null,null,"sort_order ASC,status_id ASC");try{while(c.moveToNext())names.add(c.getString(0));}finally{c.close();}if(names.isEmpty())names.add("Active");status.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names));}
    private void updateLocationText(){if(locationValue==null)return;if(latitude==null||longitude==null)locationValue.setText("No location recorded");else locationValue.setText(String.format(java.util.Locale.US,"%.6f, %.6f%s",latitude,longitude,locationSource.isEmpty()?"":"  •  "+locationSource));}
    private void captureLocation(){if(android.os.Build.VERSION.SDK_INT>=23&&ContextCompat.checkSelfPermission(this,android.Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},2001);return;}android.location.LocationManager lm=(android.location.LocationManager)getSystemService(LOCATION_SERVICE);try{android.location.Location best=null;for(String provider:new String[]{android.location.LocationManager.GPS_PROVIDER,android.location.LocationManager.NETWORK_PROVIDER}){if(lm.isProviderEnabled(provider)){android.location.Location l=lm.getLastKnownLocation(provider);if(l!=null&&(best==null||l.getAccuracy()<best.getAccuracy()))best=l;}}if(best!=null){latitude=best.getLatitude();longitude=best.getLongitude();locationSource="Captured on device";updateLocationText();Toast.makeText(this,"Location captured",Toast.LENGTH_SHORT).show();}else Toast.makeText(this,"No recent location available. Turn on Location and try again.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Could not capture location",Toast.LENGTH_SHORT).show();}}
    private void openInMaps(){if(latitude==null||longitude==null){Toast.makeText(this,"Record a location first",Toast.LENGTH_SHORT).show();return;}try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(String.format(java.util.Locale.US,"https://www.google.com/maps/search/?api=1&query=%.6f,%.6f",latitude,longitude))));}catch(Exception e){Toast.makeText(this,"Google Maps is not available",Toast.LENGTH_SHORT).show();}}

    private void choosePhoto(int index) {
        pendingPhoto = index;
        new AlertDialog.Builder(this)
                .setTitle("Member Photo")
                .setItems(new String[]{"Take photo with camera", "Choose from gallery"}, (dialog, which) -> {
                    if (which == 0) openCamera();
                    else openGallery();
                })
                .show();
    }

    private void openGallery() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("image/*");
        startActivityForResult(i, REQUEST_GALLERY);
    }

    private void openCamera() {
        if (android.os.Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{android.Manifest.permission.CAMERA}, REQUEST_CAMERA);
            return;
        }
        launchCamera();
    }

    private void launchCamera() {
        try {
            File dir = new File(getFilesDir(), "member_photos");
            if (!dir.exists() && !dir.mkdirs()) throw new IOException("Unable to create photo directory");
            cameraTempFile = new File(dir, "member_" + memberId + "_" + System.currentTimeMillis() + "_" + pendingPhoto + ".jpg");
            Uri output = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", cameraTempFile);
            Intent intent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
            intent.putExtra(MediaStore.EXTRA_OUTPUT, output);
            intent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivityForResult(intent, REQUEST_CAMERA);
        } catch (Exception e) {
            cameraTempFile = null;
            Toast.makeText(this, "Could not open camera", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 2001) { if(grantResults.length>0&&grantResults[0]==PackageManager.PERMISSION_GRANTED)captureLocation(); else Toast.makeText(this,"Location permission is needed to capture an address location",Toast.LENGTH_LONG).show(); return; }
        if (requestCode == REQUEST_CAMERA) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) launchCamera();
            else Toast.makeText(this, "Camera permission is needed to take a member photo", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_GALLERY && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri source = data.getData();
            if (pendingPhoto == 0) {
                launchCropper(source);
            } else {
                processLivePhoto(source, "hd".equals(photoQuality[pendingPhoto]));
            }
        }
        if (requestCode == REQUEST_CAMERA) {
            if (resultCode == RESULT_OK && cameraTempFile != null && cameraTempFile.exists() && cameraTempFile.length() > 0) {
                Uri source = Uri.fromFile(cameraTempFile);
                if (pendingPhoto == 0) {
                    launchCropper(source);
                } else {
                    processLivePhoto(source, "hd".equals(photoQuality[pendingPhoto]));
                }
            } else if (cameraTempFile != null) {
                cameraTempFile.delete();
            }
            if (resultCode != RESULT_OK) cameraTempFile = null;
        } else if (requestCode == REQUEST_CROP && resultCode == RESULT_OK && data != null) {
            String uri = data.getStringExtra("result_uri");
            if (uri != null && !uri.isEmpty()) {
                replacePhotoFile(0, uri);
                setPhotoImage(0);
            }
            if (cameraTempFile != null) { cameraTempFile.delete(); cameraTempFile = null; }
        }
    }

    private void launchCropper(Uri source) {
        Intent i = new Intent(this, CropActivity.class);
        i.putExtra("source", source.toString());
        i.putExtra("member_id", memberId);
        i.putExtra("slot", 0);
        startActivityForResult(i, REQUEST_CROP);
    }

    private void confirmHdToggle(int index, android.widget.CompoundButton button) {
        String today = new java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
                .format(new Date());
        android.content.SharedPreferences prefs = getSharedPreferences("churchcare_photo_preferences", MODE_PRIVATE);
        String warnedDate = prefs.getString("hd_warning_date", "");
        if (today.equals(warnedDate)) {
            photoQuality[index] = "hd";
            return;
        }

        new AlertDialog.Builder(this)
                .setTitle("HD photo")
                .setMessage("HD photos use more storage on this device and may use significantly more mobile data when ChurchCare synchronizes photos to the cloud. Standard is recommended when storage or mobile data is limited.")
                .setNegativeButton("Use Standard", (d,w) -> {
                    button.setChecked(false);
                    photoQuality[index] = "standard";
                })
                .setPositiveButton("Use HD", (d,w) -> {
                    prefs.edit().putString("hd_warning_date", today).apply();
                    photoQuality[index] = "hd";
                }).setOnCancelListener(d -> {
                    button.setChecked(false);
                    photoQuality[index] = "standard";
                }).show();
    }

    private void processLivePhoto(Uri source, boolean hd) {
        try {
            BitmapFactory.Options opts=new BitmapFactory.Options(); opts.inJustDecodeBounds=true;
            try (InputStream in=getContentResolver().openInputStream(source)) { BitmapFactory.decodeStream(in,null,opts); }
            int max=hd?2048:1280; int sample=1; while(Math.max(opts.outWidth/sample,opts.outHeight/sample)>max*2) sample*=2;
            BitmapFactory.Options dec=new BitmapFactory.Options(); dec.inSampleSize=sample;
            Bitmap b; try(InputStream in=getContentResolver().openInputStream(source)){b=BitmapFactory.decodeStream(in,null,dec);}
            if(b==null) throw new IOException("decode");
            float ratio=Math.min(1f,(float)max/Math.max(b.getWidth(),b.getHeight())); int w=Math.max(1,Math.round(b.getWidth()*ratio)),h=Math.max(1,Math.round(b.getHeight()*ratio));
            Bitmap out=(ratio<1f)?Bitmap.createScaledBitmap(b,w,h,true):b; if(out!=b)b.recycle();
            File dir=new File(getFilesDir(),"member_photos"); if(!dir.exists()&&!dir.mkdirs())throw new IOException("storage");
            File f=new File(dir,"member_"+memberId+"_photo"+(pendingPhoto+1)+"_"+System.currentTimeMillis()+".jpg");
            try(FileOutputStream fos=new FileOutputStream(f)){out.compress(Bitmap.CompressFormat.JPEG,hd?88:76,fos);}
            out.recycle(); replacePhotoFile(pendingPhoto,Uri.fromFile(f).toString()); if(pendingPhoto>0) photoQuality[pendingPhoto]=hd?"hd":"standard"; setPhotoImage(pendingPhoto);
            Toast.makeText(this,hd?"HD photo saved":"Standard photo saved",Toast.LENGTH_SHORT).show();
            if(cameraTempFile!=null && !cameraTempFile.equals(f)){cameraTempFile.delete();cameraTempFile=null;}
        } catch(Exception e){Toast.makeText(this,"Could not process that photo",Toast.LENGTH_SHORT).show();}
    }

    private void replacePhotoFile(int index, String newUri) {
        String old = photoUris[index];
        if (old != null && old.startsWith("file://") && !old.equals(newUri)) {
            try { new File(Uri.parse(old).getPath()).delete(); } catch (Exception ignored) {}
        }
        photoUris[index] = newUri;
    }

    private void pickDate() { Calendar c=Calendar.getInstance(); DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->dob.setText(String.format(java.util.Locale.US,"%04d-%02d-%02d",y,m+1,day)),c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)); d.show(); }
    private void saveMember(){ String n=name.getText().toString().trim(); if(n.isEmpty()){Toast.makeText(this,"Please enter the member's name",Toast.LENGTH_SHORT).show();return;} ContentValues v=new ContentValues();v.put("full_name",n);v.put("phone_number",phone.getText().toString().trim());v.put("date_of_birth",dob.getText().toString().trim());v.put("address",address.getText().toString().trim());v.put("status",status.getSelectedItem().toString());v.put("notes",notes.getText().toString().trim()); if(latitude!=null&&longitude!=null){v.put("latitude",latitude);v.put("longitude",longitude);v.put("location_source",locationSource);}else{v.putNull("latitude");v.putNull("longitude");v.put("location_source","");}for(int i=0;i<3;i++)v.put("photo"+(i+1)+"_uri",photoUris[i]); v.put("photo2_quality",photoQuality[1]); v.put("photo3_quality",photoQuality[2]);db.getWritableDatabase().update("members",v,"member_id=?",new String[]{String.valueOf(memberId)});Toast.makeText(this,"Member details saved",Toast.LENGTH_SHORT).show();}
    private void confirmDelete(){ new AlertDialog.Builder(this).setTitle("Delete member?").setMessage("This will permanently remove this member and the photos stored for this member from this device.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{
        for (String uri : photoUris) { if (uri != null && uri.startsWith("file://")) { try { new File(Uri.parse(uri).getPath()).delete(); } catch (Exception ignored) {} } }
        if (cameraTempFile != null) { try { cameraTempFile.delete(); } catch (Exception ignored) {} }
        db.getWritableDatabase().delete("members","member_id=?",new String[]{String.valueOf(memberId)}); finish();
    }).show(); }

    private class MemberDb extends SQLiteOpenHelper {
        MemberDb() { super(MemberDetailActivity.this, "churchcare.db", null, ChurchCareDb.VERSION); }
        @Override public void onCreate(SQLiteDatabase db) { ChurchCareDb.ensureAll(db); }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) { ChurchCareDb.ensureAll(db); }
    }
}
