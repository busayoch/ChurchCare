package com.churchcare.app;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class VisitActivity extends AppCompatActivity {
    private static final int MAX_RETAINED_VISITS = 5;
    private long memberId;
    private VisitDb db;
    private TextView dateValue;
    private Spinner type, status;
    private EditText notes;
    private CheckBox care;
    private long visitDate;

    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        memberId=getIntent().getLongExtra("member_id",-1); if(memberId<0){finish();return;}
        db=new VisitDb(); visitDate=System.currentTimeMillis();
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(0xFFF7F8F6);
        LinearLayout header=new LinearLayout(this); header.setGravity(Gravity.CENTER_VERTICAL); header.setPadding(dp(10),dp(10),dp(14),dp(10)); header.setBackgroundColor(0xFF1B5E20);
        TextView back=text("‹",42,android.graphics.Color.WHITE); back.setGravity(Gravity.CENTER); back.setOnClickListener(v->finish()); header.addView(back,new LinearLayout.LayoutParams(dp(48),dp(58)));
        TextView title=text("Record Visit",22,android.graphics.Color.WHITE); title.setTypeface(null,1); header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        TextView save=text("Save",16,android.graphics.Color.WHITE); save.setTypeface(null,1); save.setOnClickListener(v->saveVisit()); header.addView(save); root.addView(header);

        LinearLayout content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(dp(16),dp(18),dp(16),dp(24));
        TextView dlabel=text("Visit date & time",12,0xFF666666); content.addView(dlabel);
        dateValue=text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(visitDate)),16,0xFF222222); dateValue.setPadding(dp(4),dp(10),dp(4),dp(14)); dateValue.setOnClickListener(v->pickDate()); content.addView(dateValue);

        content.addView(label("Visit type")); type=new Spinner(this); String[] types={"Home Visit","Hospital","Phone Call","Counselling","Other"}; type.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,types)); content.addView(type);
        content.addView(label("Member status")); status=new Spinner(this); loadStatuses(); content.addView(status);
        content.addView(label("Summary notes")); notes=new EditText(this); notes.setHint("What happened during the visit?"); notes.setMinLines(5); notes.setGravity(Gravity.TOP); content.addView(notes);
        care=new CheckBox(this); care.setText("Care / need identified"); care.setTextSize(16); content.addView(care);
        root.addView(content,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
    }
    private TextView label(String s){TextView t=text(s,12,0xFF666666);t.setPadding(dp(4),dp(12),dp(4),dp(2));return t;}
    private void loadStatuses(){
        java.util.ArrayList<String> a=new java.util.ArrayList<>(); SQLiteDatabase s=db.getReadableDatabase(); android.database.Cursor c=s.query("statuses",new String[]{"name"},null,null,null,null,"sort_order ASC"); try{while(c.moveToNext())a.add(c.getString(0));}finally{c.close();}
        if(a.isEmpty())a.add("Active"); status.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));
    }
    private void pickDate(){Calendar c=Calendar.getInstance();c.setTimeInMillis(visitDate);new DatePickerDialog(this,(v,y,m,d)->{Calendar n=Calendar.getInstance();n.set(y,m,d,c.get(Calendar.HOUR_OF_DAY),c.get(Calendar.MINUTE),0);visitDate=n.getTimeInMillis();dateValue.setText(DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(visitDate)));},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private void saveVisit(){
        ContentValues v=new ContentValues();v.put("member_id",memberId);v.put("visit_date",visitDate);v.put("visit_type",type.getSelectedItem().toString());v.put("member_status",status.getSelectedItem().toString());v.put("notes",notes.getText().toString().trim());v.put("care_need",care.isChecked()?1:0);
        SQLiteDatabase database=db.getWritableDatabase();
        database.beginTransaction();
        try {
            database.insertOrThrow("member_visits",null,v);
            // Privacy-first retention: keep only the five most recent visit records for this member.
            database.delete("member_visits", "member_id=? AND visit_id NOT IN (SELECT visit_id FROM member_visits WHERE member_id=? ORDER BY visit_date DESC, visit_id DESC LIMIT " + MAX_RETAINED_VISITS + ")",
                    new String[]{String.valueOf(memberId),String.valueOf(memberId)});
            database.setTransactionSuccessful();
        } finally { database.endTransaction(); }
        Toast.makeText(this,"Visit recorded",Toast.LENGTH_SHORT).show(); finish();
    }

    private class VisitDb extends SQLiteOpenHelper {
        VisitDb(){super(VisitActivity.this,"churchcare.db",null,ChurchCareDb.VERSION);}
        public void onCreate(SQLiteDatabase d){ChurchCareDb.ensureAll(d);}
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){ChurchCareDb.ensureAll(d);}
    }
}
