package com.churchcare.app;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

/**
 * Small, dependency-free synchronization coordinator for the local queue.
 *
 * This class deliberately does not contact Google Drive or a remote API yet.
 * It provides the durable local contract that a future provider can consume.
 */
public final class ChurchCareSync {
    public static final String PENDING = "PENDING";
    public static final String FAILED = "FAILED";
    public static final String SENT = "SENT";
    public static final String TOMBSTONE = "TOMBSTONE";

    private ChurchCareSync() {}

    public static final class QueueItem {
        public final long queueId;
        public final String syncId;
        public final String entityType;
        public final long localId;
        public final String operation;
        public final String payloadJson;
        public final int attemptCount;

        QueueItem(long queueId, String syncId, String entityType, long localId,
                  String operation, String payloadJson, int attemptCount) {
            this.queueId = queueId;
            this.syncId = syncId;
            this.entityType = entityType;
            this.localId = localId;
            this.operation = operation;
            this.payloadJson = payloadJson;
            this.attemptCount = attemptCount;
        }
    }

    /** Returns the oldest pending/failed queue items for a future provider. */
    public static List<QueueItem> nextBatch(SQLiteDatabase db, int limit) {
        ArrayList<QueueItem> items = new ArrayList<>();
        Cursor c = db.rawQuery(
                "SELECT queue_id,sync_id,entity_type,local_id,operation,payload_json,attempt_count " +
                "FROM sync_queue WHERE status IN ('PENDING','FAILED') ORDER BY queue_id ASC LIMIT ?",
                new String[]{String.valueOf(Math.max(1, limit))});
        try {
            while (c.moveToNext()) {
                items.add(new QueueItem(
                        c.getLong(0), c.getString(1), c.getString(2), c.getLong(3),
                        c.getString(4), c.getString(5), c.getInt(6)));
            }
        } finally {
            c.close();
        }
        return items;
    }

    public static int pendingCount(SQLiteDatabase db) {
        return ChurchCareDb.pendingSyncCount(db);
    }

    public static void begin(SQLiteDatabase db) {
        ContentValues v = new ContentValues();
        v.put("is_syncing", 1);
        v.putNull("last_error");
        db.update("sync_state", v, "state_id=1", null);
    }

    public static void finish(SQLiteDatabase db, boolean success, String error) {
        long now = System.currentTimeMillis();
        ContentValues v = new ContentValues();
        v.put("is_syncing", 0);
        v.put("last_sync_at", now);
        if (success) {
            v.put("last_success_at", now);
            v.putNull("last_error");
        } else {
            v.put("last_error", error == null ? "Synchronization failed" : error);
        }
        db.update("sync_state", v, "state_id=1", null);
    }

    public static void markSuccess(SQLiteDatabase db, QueueItem item) {
        long now = System.currentTimeMillis();
        ContentValues q = new ContentValues();
        q.put("status", SENT);
        q.put("last_attempt_at", now);
        q.put("attempt_count", item.attemptCount + 1);
        q.putNull("last_error");
        db.update("sync_queue", q, "queue_id=?", new String[]{String.valueOf(item.queueId)});

        ContentValues r = new ContentValues();
        r.put("state", "SYNCED");
        r.put("last_synced_at", now);
        r.put("updated_at", now);
        r.put("last_error", (String)null);
        db.update("sync_records", r, "sync_id=?", new String[]{item.syncId});
    }

    public static void markFailure(SQLiteDatabase db, QueueItem item, String error) {
        long now = System.currentTimeMillis();
        ContentValues q = new ContentValues();
        q.put("status", FAILED);
        q.put("last_attempt_at", now);
        q.put("attempt_count", item.attemptCount + 1);
        q.put("last_error", error == null ? "Synchronization failed" : error);
        db.update("sync_queue", q, "queue_id=?", new String[]{String.valueOf(item.queueId)});

        ContentValues r = new ContentValues();
        r.put("state", "PENDING");
        r.put("updated_at", now);
        r.put("last_error", error == null ? "Synchronization failed" : error);
        db.update("sync_records", r, "sync_id=?", new String[]{item.syncId});
    }

    public static void setPullCursor(SQLiteDatabase db, String cursor) {
        ContentValues v = new ContentValues();
        if (cursor == null) v.putNull("last_pull_cursor"); else v.put("last_pull_cursor", cursor);
        db.update("sync_state", v, "state_id=1", null);
    }
}
