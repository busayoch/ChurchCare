package com.churchcare.app;

import android.app.DatePickerDialog;
import java.util.Calendar;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

public class CareActivity extends AppCompatActivity {
    private long memberId; private CareDb db; private LinearLayout list; private TextView empty; private String memberName="";
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,float z,int c){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);return t;}
    @Override protected void onCreate(Bundle b){super.onCreate(b);memberId=getIntent().getLongExtra("member_id",-1);if(memberId<0){finish();return;}db=new CareDb();loadMemberName();build();refresh();}
    private void build(){LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFFF7F8F6);
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(10),dp(10),dp(14),dp(10));h.setBackgroundColor(0xFF1B5E20);
        TextView back=text("‹",42,Color.WHITE);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());h.addView(back,new LinearLayout.LayoutParams(dp(48),dp(58)));
        TextView title=text("Care Management",21,Color.WHITE);title.setTypeface(null,Typeface.BOLD);h.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(h); LinearLayout bar=new LinearLayout(this);bar.setPadding(dp(16),dp(12),dp(16),dp(4));
        TextView add=text("+ Create Care Ticket",16,0xFF6B4EAA);add.setTypeface(null,Typeface.BOLD);add.setGravity(Gravity.CENTER_VERTICAL);add.setOnClickListener(v->createTicket());bar.addView(add,new LinearLayout.LayoutParams(-1,dp(52)));root.addView(bar);
        ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(dp(16),dp(8),dp(16),dp(24));sv.addView(list);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    private void loadMemberName(){Cursor c=db.getReadableDatabase().query("members",new String[]{"full_name"},"member_id=?",new String[]{String.valueOf(memberId)},null,null,null);try{if(c.moveToFirst())memberName=c.getString(0);}finally{c.close();}}
    private void refresh(){list.removeAllViews();Cursor c=db.getReadableDatabase().query("care_tickets",null,"member_id=?",new String[]{String.valueOf(memberId)},null,null,"updated_at DESC");boolean any=false;try{while(c.moveToNext()){any=true;final long id=c.getLong(c.getColumnIndexOrThrow("ticket_id"));String cat=c.getString(c.getColumnIndexOrThrow("category"));String st=c.getString(c.getColumnIndexOrThrow("status"));String desc=c.getString(c.getColumnIndexOrThrow("description"));String assigned=c.getString(c.getColumnIndexOrThrow("assigned_to"));long follow=c.isNull(c.getColumnIndexOrThrow("follow_up_at"))?0:c.getLong(c.getColumnIndexOrThrow("follow_up_at"));long tm=c.getLong(c.getColumnIndexOrThrow("updated_at"));LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(dp(14),dp(12),dp(14),dp(12));card.setBackgroundColor(Color.WHITE);TextView a=text(cat+"  •  "+st,17,0xFF222222);a.setTypeface(null,Typeface.BOLD);card.addView(a);TextView d=text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM,DateFormat.SHORT).format(new Date(tm)),12,0xFF777777);card.addView(d);if(assigned!=null&&!assigned.isEmpty()){TextView q=text("Assigned: "+assigned,13,0xFF555555);q.setPadding(0,dp(4),0,0);card.addView(q);}if(follow>0){TextView q=text("Follow-up: "+DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(follow)),13,0xFF555555);q.setPadding(0,dp(3),0,0);card.addView(q);}if(desc!=null&&!desc.isEmpty()){TextView x=text(desc,14,0xFF444444);x.setPadding(0,dp(6),0,0);card.addView(x);}card.setOnClickListener(v->ticketDetail(id));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(10));list.addView(card,lp);}}finally{c.close();}if(!any){empty=text("No care tickets for this member yet.",15,0xFF777777);empty.setGravity(Gravity.CENTER);list.addView(empty,new LinearLayout.LayoutParams(-1,dp(100)));}}
    private void createTicket(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),0,dp(18),0);
        Spinner cat=new Spinner(this);ArrayList<String> cats=new ArrayList<>();
        Cursor cc=db.getReadableDatabase().query("care_categories",new String[]{"name"},"enabled=1",null,null,null,"sort_order ASC,name ASC");
        try{while(cc.moveToNext())cats.add(cc.getString(0));}finally{cc.close();}
        if(cats.isEmpty())cats.add("General");cat.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,cats));
        box.addView(label("Category"));box.addView(cat);
        EditText desc=new EditText(this);desc.setHint("Describe the need");desc.setMinLines(4);desc.setGravity(Gravity.TOP);box.addView(label("Description"));box.addView(desc);
        EditText cost=new EditText(this);cost.setHint("Estimated cost (optional)");cost.setInputType(2|8192);box.addView(label("Estimated cost"));box.addView(cost);
        EditText org=new EditText(this);org.setHint("Current handling organization (optional)");box.addView(label("Handling organization"));box.addView(org);
        EditText assigned=new EditText(this);assigned.setHint("Pastor / worker responsible (optional)");box.addView(label("Assigned to"));box.addView(assigned);
        TextView follow=text("No follow-up date",16,0xFF333333);follow.setPadding(dp(4),dp(10),dp(4),dp(12));box.addView(label("Follow-up date (optional)"));box.addView(follow);
        final long[] followAt={0};follow.setOnClickListener(v->pickFollowUp(follow,followAt));
        new AlertDialog.Builder(this).setTitle("Create Care Ticket").setMessage(memberName).setView(box).setNegativeButton("Cancel",null).setPositiveButton("Create",(d,w)->{
            ContentValues v=new ContentValues();long now=System.currentTimeMillis();v.put("member_id",memberId);v.put("category",cat.getSelectedItem().toString());v.put("description",desc.getText().toString().trim());
            String cs=cost.getText().toString().trim();if(!cs.isEmpty())try{v.put("estimated_cost",Double.parseDouble(cs));}catch(Exception ignored){}
            v.put("handling_org",org.getText().toString().trim());v.put("assigned_to",assigned.getText().toString().trim());if(followAt[0]>0)v.put("follow_up_at",followAt[0]);
            v.put("status","OPEN");v.put("created_at",now);v.put("updated_at",now);
            long id=db.getWritableDatabase().insertOrThrow("care_tickets",null,v);addEvent(id,null,"OPEN","CREATED","Local",org.getText().toString().trim(),"");refresh();Toast.makeText(this,"Care ticket created",Toast.LENGTH_SHORT).show();
        }).show();
    }
    private void pickFollowUp(TextView target,long[] value){Calendar c=Calendar.getInstance();new DatePickerDialog(this,(v,y,m,d)->{Calendar n=Calendar.getInstance();n.set(y,m,d,9,0,0);value[0]=n.getTimeInMillis();target.setText(DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(value[0])));},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    private TextView label(String s){TextView t=text(s,12,0xFF666666);t.setPadding(0,dp(10),0,dp(2));return t;}
    private void ticketDetail(long id){Cursor c=db.getReadableDatabase().query("care_tickets",null,"ticket_id=?",new String[]{String.valueOf(id)},null,null,null);if(!c.moveToFirst()){c.close();return;}String cat=c.getString(c.getColumnIndexOrThrow("category"));String st=c.getString(c.getColumnIndexOrThrow("status"));String desc=c.getString(c.getColumnIndexOrThrow("description"));String cost=c.isNull(c.getColumnIndexOrThrow("estimated_cost"))?"":String.valueOf(c.getDouble(c.getColumnIndexOrThrow("estimated_cost")));String org=c.getString(c.getColumnIndexOrThrow("handling_org"));String assigned=c.getString(c.getColumnIndexOrThrow("assigned_to"));long follow=c.isNull(c.getColumnIndexOrThrow("follow_up_at"))?0:c.getLong(c.getColumnIndexOrThrow("follow_up_at"));String resolution=c.getString(c.getColumnIndexOrThrow("resolution_note"));c.close();LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),0,dp(18),0);TextView info=text("Category: "+cat+"\nStatus: "+st+"\nEstimated cost: "+(cost.isEmpty()?"Not specified":cost)+"\nHandling: "+(org==null||org.isEmpty()?"Not specified":org)+"\nAssigned to: "+(assigned==null||assigned.isEmpty()?"Not assigned":assigned)+"\nFollow-up: "+(follow==0?"Not scheduled":DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(follow)))+"\nResolution: "+(resolution==null||resolution.isEmpty()?"Not resolved":resolution)+"\n\n"+(desc==null?"":desc),15,0xFF333333);box.addView(info);TextView history=text("\nHistory",16,0xFF222222);history.setTypeface(null,Typeface.BOLD);box.addView(history);Cursor e=db.getReadableDatabase().query("care_ticket_events",null,"ticket_id=?",new String[]{String.valueOf(id)},null,null,"event_time ASC");try{while(e.moveToNext()){String ev=e.getString(e.getColumnIndexOrThrow("event_type"));String fs=e.getString(e.getColumnIndexOrThrow("from_status"));String ts=e.getString(e.getColumnIndexOrThrow("to_status"));String note=e.getString(e.getColumnIndexOrThrow("note"));TextView row=text(DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(e.getLong(e.getColumnIndexOrThrow("event_time"))))+"  "+ev+"  "+(fs==null?"":fs)+" → "+(ts==null?"":ts)+(note==null||note.isEmpty()?"":"\n"+note),13,0xFF555555);row.setPadding(0,dp(5),0,dp(5));box.addView(row);}}finally{e.close();}
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Care Ticket #"+id).setView(box).setNegativeButton("Close",null).setNeutralButton("Update status",null).setPositiveButton("Escalate upward",null).create();dlg.setOnShowListener(x->{dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->updateStatus(id));dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->escalate(id));});dlg.show();}
    private void updateStatus(long id){String[] a={"OPEN","APPROVED","RESOLVED","REJECTED"};new AlertDialog.Builder(this).setTitle("Update ticket status").setItems(a,(d,w)->{if("RESOLVED".equals(a[w]))captureResolution(id);else changeStatus(id,a[w],"STATUS_UPDATED","Local","Local","");}).show();}
    private void captureResolution(long id){EditText e=new EditText(this);e.setHint("What was done / outcome (optional)");e.setMinLines(3);new AlertDialog.Builder(this).setTitle("Resolve care ticket").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{SQLiteDatabase s=db.getWritableDatabase();ContentValues v=new ContentValues();v.put("status","RESOLVED");v.put("resolution_note",e.getText().toString().trim());v.put("updated_at",System.currentTimeMillis());s.update("care_tickets",v,"ticket_id=?",new String[]{String.valueOf(id)});addEvent(id,"OPEN","RESOLVED","RESOLVED","Local","Local",e.getText().toString().trim());refresh();}).show();}
    private void escalate(long id){new AlertDialog.Builder(this).setTitle("Escalate care ticket").setMessage("This will mark the ticket as ESCALATED and record an escalation event. Hierarchy routing will be connected when the configurable church structure is added.").setNegativeButton("Cancel",null).setPositiveButton("Escalate",(d,w)->changeStatus(id,"ESCALATED","ESCALATED","Local","Parent (not configured)","Escalated upward" )).show();}
    private void changeStatus(long id,String to,String event,String fromOrg,String toOrg,String note){SQLiteDatabase s=db.getWritableDatabase();String from="OPEN";Cursor c=s.query("care_tickets",new String[]{"status"},"ticket_id=?",new String[]{String.valueOf(id)},null,null,null);try{if(c.moveToFirst())from=c.getString(0);}finally{c.close();}ContentValues v=new ContentValues();v.put("status",to);v.put("updated_at",System.currentTimeMillis());s.update("care_tickets",v,"ticket_id=?",new String[]{String.valueOf(id)});addEvent(id,from,to,event,fromOrg,toOrg,note);refresh();Toast.makeText(this,"Ticket updated",Toast.LENGTH_SHORT).show();}
    private void addEvent(long id,String fs,String ts,String ev,String fo,String to,String note){ContentValues v=new ContentValues();v.put("ticket_id",id);if(fs==null)v.putNull("from_status");else v.put("from_status",fs);if(ts==null)v.putNull("to_status");else v.put("to_status",ts);v.put("event_type",ev);v.put("from_org",fo);v.put("to_org",to);v.put("event_time",System.currentTimeMillis());v.put("note",note);db.getWritableDatabase().insert("care_ticket_events",null,v);}

    private class CareDb extends SQLiteOpenHelper {
        CareDb(){super(CareActivity.this,"churchcare.db",null,ChurchCareDb.VERSION);}
        public void onCreate(SQLiteDatabase d){ChurchCareDb.ensureAll(d);}
        public void onUpgrade(SQLiteDatabase d,int oldV,int newV){ChurchCareDb.ensureAll(d);}
    }
}
