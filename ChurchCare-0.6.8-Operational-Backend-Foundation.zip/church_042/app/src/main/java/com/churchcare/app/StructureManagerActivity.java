package com.churchcare.app;

import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

/** Visual, data-driven church organization editor with a localized branch view. */
public class StructureManagerActivity extends AppCompatActivity {
    private StructureDb db;
    private LinearLayout tree;
    private TextView churchValue;
    private Spinner focusSpinner;
    private ArrayList<Long> focusIds = new ArrayList<>();
    private final SharedPreferences prefs() { return getSharedPreferences("churchcare_structure", MODE_PRIVATE); }
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
    private TextView text(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    private int green(){return 0xFF1B5E20;}

    @Override protected void onCreate(Bundle b){super.onCreate(b);db=new StructureDb();buildUi();refreshAll();}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(0xFFF7F8F6);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(dp(10),dp(8),dp(14),dp(8));header.setBackgroundColor(green());
        TextView back=text("‹",42,Color.WHITE);back.setGravity(Gravity.CENTER);back.setOnClickListener(v->finish());header.addView(back,new LinearLayout.LayoutParams(dp(48),dp(56)));
        TextView title=text("Church Structure",21,Color.WHITE);title.setTypeface(null,Typeface.BOLD);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));root.addView(header);

        ScrollView outer=new ScrollView(this);LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(dp(14),dp(12),dp(14),dp(24));outer.addView(content);
        LinearLayout churchCard=card();TextView ch=text("Church / Tenant",18,Color.BLACK);ch.setTypeface(null,Typeface.BOLD);churchCard.addView(ch);
        churchValue=text("Not configured",14,0xFF555555);churchValue.setPadding(0,dp(5),0,dp(8));churchCard.addView(churchValue);
        Button editChurch=new Button(this);editChurch.setText("Edit church / join code");editChurch.setOnClickListener(v->editChurch());churchCard.addView(editChurch);content.addView(churchCard);

        TextView h=text("Visual Organization Structure",22,Color.BLACK);h.setTypeface(null,Typeface.BOLD);h.setPadding(0,dp(12),0,dp(4));content.addView(h);
        TextView hint=text("The tree is focused on one organization at a time: see the connection above you and the whole branch below you. Other unrelated branches stay out of view.",14,0xFF666666);hint.setPadding(0,0,0,dp(8));content.addView(hint);

        LinearLayout focusCard=card();TextView fl=text("View from this organization",14,0xFF555555);fl.setTypeface(null,Typeface.BOLD);focusCard.addView(fl);
        focusSpinner=new Spinner(this);focusCard.addView(focusSpinner,new LinearLayout.LayoutParams(-1,dp(48)));content.addView(focusCard);

        HorizontalScrollView hsv=new HorizontalScrollView(this);hsv.setFillViewport(false);ZoomLayout zoom=new ZoomLayout(this);tree=new LinearLayout(this);tree.setOrientation(LinearLayout.VERTICAL);tree.setPadding(dp(12),dp(12),dp(28),dp(20));zoom.addView(tree);hsv.addView(zoom,new HorizontalScrollView.LayoutParams(-2,-2));content.addView(hsv,new LinearLayout.LayoutParams(-1,dp(470)));
        TextView zoomHint=text("Tip: pinch to zoom the tree. Scroll sideways to see wider branches.",12,0xFF777777);zoomHint.setGravity(Gravity.CENTER);zoomHint.setPadding(0,dp(4),0,dp(8));content.addView(zoomHint);

        LinearLayout tools=new LinearLayout(this);tools.setOrientation(LinearLayout.HORIZONTAL);tools.setGravity(Gravity.CENTER_VERTICAL);tools.setPadding(0,dp(4),0,dp(6));
        Button levels=new Button(this);levels.setText("Manage Levels");levels.setOnClickListener(v->manageLevels());tools.addView(levels,new LinearLayout.LayoutParams(0,dp(50),1));
        Button leader=new Button(this);leader.setText("Leadership");leader.setOnClickListener(v->showLeadership());LinearLayout.LayoutParams l2=new LinearLayout.LayoutParams(0,dp(50),1);l2.setMargins(dp(6),0,0,0);tools.addView(leader,l2);content.addView(tools);
        Button pastors=new Button(this);pastors.setText("Pastor Assignments");pastors.setOnClickListener(v->startActivity(new android.content.Intent(this,PastoralAssignmentActivity.class)));content.addView(pastors);
        Button addTop=new Button(this);addTop.setText("＋ Add organization");addTop.setOnClickListener(v->addOrganization(-1,-1));content.addView(addTop);
        root.addView(outer,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
    }

    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(12),dp(10),dp(12),dp(10));c.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,dp(8));c.setLayoutParams(p);return c;}

    private void refreshAll(){refreshChurch();refreshFocusSelector();renderTree();}
    private void refreshChurch(){Cursor c=db.getReadableDatabase().query("church_profile",null,null,null,null,null,"church_id ASC","1");try{if(c.moveToFirst())churchValue.setText(c.getString(c.getColumnIndexOrThrow("church_name"))+"\nParent Join Code: "+c.getString(c.getColumnIndexOrThrow("join_code")));else churchValue.setText("Not configured");}finally{c.close();}}

    private static class Org {long id;String name;long level;Long parent;Org(long i,String n,long l,Long p){id=i;name=n;level=l;parent=p;}}
    private static class Level {long id;String name;int order;Level(long i,String n,int o){id=i;name=n;order=o;}}

    private ArrayList<Org> readOrganizations(){ArrayList<Org> a=new ArrayList<>();Cursor c=db.getReadableDatabase().query("organizations",new String[]{"organization_id","name","level_id","parent_id"},null,null,null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext())a.add(new Org(c.getLong(0),c.getString(1),c.getLong(2),c.isNull(3)?null:c.getLong(3)));}finally{c.close();}return a;}

    private void refreshFocusSelector(){
        if(focusSpinner==null)return;
        ArrayList<Org> orgs=readOrganizations();ArrayList<String> names=new ArrayList<>();focusIds.clear();
        names.add("Choose an organization to focus the tree");focusIds.add(-1L);
        for(Org o:orgs){names.add(o.name);focusIds.add(o.id);}
        focusSpinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names));
        long saved=prefs().getLong("focus_org_id",-1L);int selected=0;
        if(saved!=-1L){for(int i=0;i<focusIds.size();i++)if(focusIds.get(i)==saved){selected=i;break;}}
        if(selected==0&&orgs.size()>0){selected=1;prefs().edit().putLong("focus_org_id",orgs.get(0).id).apply();}
        focusSpinner.setSelection(selected,false);
        focusSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){if(pos<focusIds.size()&&focusIds.get(pos)!=-1L){prefs().edit().putLong("focus_org_id",focusIds.get(pos)).apply();renderTree();}}});
    }

    private void renderTree(){
        if(tree==null)return;tree.removeAllViews();SQLiteDatabase s=db.getReadableDatabase();
        ArrayList<Level> levels=readLevels();if(levels.isEmpty()){tree.addView(text("No hierarchy levels yet. Use Manage Levels to create one.",15,0xFF666666));return;}
        ArrayList<Org> orgs=readOrganizations();if(orgs.isEmpty()){emptyLevelRow(tree,levels.get(0),null,"No organization yet. Add the first organization to start the tree.");return;}
        Map<Long,Org> byId=new HashMap<>();Map<Long,ArrayList<Org>> children=new HashMap<>();Map<Long,String> levelNames=new HashMap<>();for(Org o:orgs){byId.put(o.id,o);long k=o.parent==null?0:o.parent;ArrayList<Org> list=children.get(k);if(list==null){list=new ArrayList<>();children.put(k,list);}list.add(o);}for(Level l:levels)levelNames.put(l.id,l.name);
        long focusId=prefs().getLong("focus_org_id",orgs.get(0).id);Org focus=byId.get(focusId);if(focus==null)focus=orgs.get(0);

        TextView title=text("YOUR VIEW",12,0xFF2E7D32);title.setTypeface(null,Typeface.BOLD);title.setGravity(Gravity.CENTER);tree.addView(title);
        TextView focusLabel=text("Focused on: "+focus.name,18,Color.BLACK);focusLabel.setTypeface(null,Typeface.BOLD);focusLabel.setGravity(Gravity.CENTER);focusLabel.setPadding(0,dp(4),0,dp(12));tree.addView(focusLabel);

        ArrayList<Org> ancestors=new ArrayList<>();Org cur=focus;while(cur!=null){ancestors.add(0,cur);cur=cur.parent==null?null:byId.get(cur.parent);}
        if(ancestors.size()>1){TextView up=text("↑ Reporting connection",12,0xFF777777);up.setGravity(Gravity.CENTER);tree.addView(up);for(int i=0;i<ancestors.size()-1;i++){Org a=ancestors.get(i);addPathNode(a,levelNames.get(a.level),false);addConnector(tree,"│");} }
        addPathNode(focus,levelNames.get(focus.level),true);
        ArrayList<Org> direct=children.get(focus.id);if(direct==null)direct=new ArrayList<>();
        if(direct.isEmpty()){TextView no=text("No organizations directly below this level yet.\nThis organization may remain here without children.",14,0xFF777777);no.setGravity(Gravity.CENTER);no.setPadding(dp(12),dp(14),dp(12),dp(14));tree.addView(no);}else{
            addConnector(tree,"│");TextView down=text("↓ Organizations under "+focus.name,12,0xFF777777);down.setGravity(Gravity.CENTER);down.setPadding(0,0,0,dp(6));tree.addView(down);renderChildren(tree,direct,children,levelNames,0);
        }
    }

    private void addPathNode(Org o,String levelName,boolean focused){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER);box.setPadding(dp(18),dp(10),dp(18),dp(10));box.setBackgroundColor(focused?0xFFE8F5E9:Color.WHITE);TextView l=text(levelName==null?"ORGANIZATION":levelName.toUpperCase(Locale.US),11,0xFF555555);l.setTypeface(null,Typeface.BOLD);l.setGravity(Gravity.CENTER);box.addView(l);TextView n=text(o.name,18,Color.BLACK);n.setTypeface(null,Typeface.BOLD);n.setGravity(Gravity.CENTER);box.addView(n);if(focused){TextView f=text("CURRENT FOCUS",10,0xFF2E7D32);f.setTypeface(null,Typeface.BOLD);f.setGravity(Gravity.CENTER);box.addView(f);}LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(dp(260),-2);p.gravity=Gravity.CENTER;p.setMargins(0,dp(3),0,dp(3));tree.addView(box,p);}
    private void addConnector(LinearLayout target,String s){TextView c=text(s,20,0xFF9E9E9E);c.setGravity(Gravity.CENTER);target.addView(c,new LinearLayout.LayoutParams(-1,dp(28)));}

    private void renderChildren(LinearLayout target,ArrayList<Org> siblings,Map<Long,ArrayList<Org>> children,Map<Long,String> levelNames,int depth){
        if(siblings==null||siblings.isEmpty())return;String levelName=levelNames.get(siblings.get(0).level);
        TextView label=text((levelName==null?"LEVEL":levelName).toUpperCase(Locale.US),12,0xFF555555);label.setTypeface(null,Typeface.BOLD);label.setGravity(Gravity.CENTER);target.addView(label);
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.setGravity(Gravity.TOP);row.setPadding(dp(4),0,dp(4),dp(6));
        for(Org o:siblings){LinearLayout node=orgNode(o,levelName,children);row.addView(node,new LinearLayout.LayoutParams(dp(210),-2));}
        Button add=new Button(this);add.setText("＋ Add another\n"+(levelName==null?"level":levelName));add.setOnClickListener(v->addOrganization(siblings.get(0).level,-1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(dp(190),dp(78));ap.setMargins(dp(8),0,0,0);row.addView(add,ap);target.addView(row);
        // Continue downward so the focused branch includes every descendant level.
        for(Org o:siblings){ArrayList<Org> ch=children.get(o.id);if(ch!=null&&!ch.isEmpty()){addConnector(target,"│");TextView branch=text("└─ Below "+o.name,11,0xFF888888);branch.setGravity(Gravity.CENTER);target.addView(branch);renderChildren(target,ch,children,levelNames,depth+1);}}
    }

    private LinearLayout orgNode(Org o,String levelName,Map<Long,ArrayList<Org>> children){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),dp(9),dp(10),dp(8));box.setBackgroundColor(0xFFFFFFFF);TextView l=text(levelName==null?"Organization":levelName,11,0xFF777777);l.setTypeface(null,Typeface.BOLD);box.addView(l);TextView n=text(o.name,16,Color.BLACK);n.setTypeface(null,Typeface.BOLD);box.addView(n);ArrayList<Org> ch=children.get(o.id);box.addView(text((ch==null?0:ch.size())+" direct child"+((ch!=null&&ch.size()==1)?"":"ren"),12,0xFF666666));LinearLayout actions=new LinearLayout(this);actions.setOrientation(LinearLayout.HORIZONTAL);Button focus=new Button(this);focus.setText("View");focus.setOnClickListener(v->{prefs().edit().putLong("focus_org_id",o.id).apply();if(focusSpinner!=null){int idx=focusIds.indexOf(o.id);if(idx>=0)focusSpinner.setSelection(idx);}renderTree();});actions.addView(focus,new LinearLayout.LayoutParams(0,dp(44),1));Button edit=new Button(this);edit.setText("Edit");edit.setOnClickListener(v->editOrganization(o));actions.addView(edit,new LinearLayout.LayoutParams(0,dp(44),1));box.addView(actions);Button child=new Button(this);child.setText("＋ Add child");child.setOnClickListener(v->addChild(o));box.addView(child);return box;}

    private void emptyLevelRow(LinearLayout target,Level level,Long parentId,String msg){TextView l=text(level.name.toUpperCase(Locale.US),13,0xFF555555);l.setTypeface(null,Typeface.BOLD);target.addView(l);TextView e=text(msg,14,0xFF777777);e.setPadding(dp(10),dp(8),0,dp(8));target.addView(e);Button add=new Button(this);add.setText("＋ Add "+level.name);add.setOnClickListener(v->addOrganization(level.id,parentId));target.addView(add);}

    private void addChild(Org parent){long childLevel=findNextLevel(parent.level);if(childLevel==-1){Toast.makeText(this,"No lower hierarchy level exists. Add another level first.",Toast.LENGTH_LONG).show();return;}addOrganization(childLevel,parent.id);}
    private long findNextLevel(long levelId){Cursor c=db.getReadableDatabase().rawQuery("SELECT level_id FROM hierarchy_levels WHERE enabled=1 AND sort_order>(SELECT sort_order FROM hierarchy_levels WHERE level_id=?) ORDER BY sort_order ASC LIMIT 1",new String[]{String.valueOf(levelId)});try{return c.moveToFirst()?c.getLong(0):-1;}finally{c.close();}}

    private void addOrganization(long preselectedLevel,long preselectedParent){ArrayList<Level> levels=readLevels();if(levels.isEmpty()){Toast.makeText(this,"Add a hierarchy level first",Toast.LENGTH_SHORT).show();return;}LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),0,dp(18),0);EditText name=new EditText(this);name.setHint("Organization name");box.addView(name);Spinner level=new Spinner(this);ArrayList<String> ln=new ArrayList<>();int selected=0;for(int i=0;i<levels.size();i++){ln.add(levels.get(i).name);if(levels.get(i).id==preselectedLevel)selected=i;}level.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,ln));if(preselectedLevel!=-1)level.setSelection(selected);box.addView(level);Spinner parent=new Spinner(this);box.addView(parent);ArrayList<Long> parentIds=new ArrayList<>();
        Runnable updateParents=()->{parentIds.clear();ArrayList<String> pn=new ArrayList<>();int idx=level.getSelectedItemPosition();if(idx<0||idx>=levels.size()){parent.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,pn));return;}Level chosen=levels.get(idx);pn.add("No parent (top level)");parentIds.add(-1L);Level prev=null;for(Level x:levels)if(x.order<chosen.order&&(prev==null||x.order>prev.order))prev=x;if(prev!=null){Cursor c=db.getReadableDatabase().query("organizations",new String[]{"organization_id","name"},"level_id=?",new String[]{String.valueOf(prev.id)},null,null,"name COLLATE NOCASE ASC");try{while(c.moveToNext()){pn.add(c.getString(1));parentIds.add(c.getLong(0));}}finally{c.close();}}parent.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,pn));};level.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){updateParents.run();}});updateParents.run();if(preselectedParent!=-1){int pi=parentIds.indexOf(preselectedParent);if(pi>=0)parent.setSelection(pi);}
        new AlertDialog.Builder(this).setTitle("Add organization").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{String n=name.getText().toString().trim();if(n.isEmpty())return;int li=level.getSelectedItemPosition();if(li<0||li>=levels.size()){Toast.makeText(this,"Please select an organization level",Toast.LENGTH_SHORT).show();return;}int pi=parent.getSelectedItemPosition();long pid=(pi>=0&&pi<parentIds.size())?parentIds.get(pi):-1L;ContentValues v=new ContentValues();v.put("name",n);v.put("level_id",levels.get(li).id);if(pid!=-1)v.put("parent_id",pid);v.put("join_code",makeCode());v.put("created_at",System.currentTimeMillis());if(db.getWritableDatabase().insert("organizations",null,v)==-1)Toast.makeText(this,"Could not add organization",Toast.LENGTH_SHORT).show();else Toast.makeText(this,"Organization added",Toast.LENGTH_SHORT).show();refreshAll();}).show();}

    private ArrayList<Level> readLevels(){ArrayList<Level> a=new ArrayList<>();Cursor c=db.getReadableDatabase().query("hierarchy_levels",new String[]{"level_id","name","sort_order"},"enabled=1",null,null,null,"sort_order ASC,name ASC");try{while(c.moveToNext())a.add(new Level(c.getLong(0),c.getString(1),c.getInt(2)));}finally{c.close();}return a;}
    private void manageLevels(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);TextView info=text("Rename, add, or remove unused levels. Removing a level never removes member data.",14,0xFF666666);info.setPadding(dp(12),dp(8),dp(12),dp(8));box.addView(info);ArrayList<Level> lv=readLevels();for(Level l:lv){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView n=text(l.name,16,Color.BLACK);n.setTypeface(null,Typeface.BOLD);r.addView(n,new LinearLayout.LayoutParams(0,dp(48),1));Button e=new Button(this);e.setText("Edit");e.setOnClickListener(v->editLevel(l.id,l.name));r.addView(e);Button x=new Button(this);x.setText("Delete");x.setOnClickListener(v->deleteLevel(l.id,l.name));r.addView(x);box.addView(r);}Button add=new Button(this);add.setText("＋ Add hierarchy level");add.setOnClickListener(v->addLevel());box.addView(add);new AlertDialog.Builder(this).setTitle("Manage Hierarchy Levels").setView(box).setPositiveButton("Done",null).show();}
    private void addLevel(){EditText e=new EditText(this);e.setHint("Level name");new AlertDialog.Builder(this).setTitle("Add hierarchy level").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Add",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;ContentValues v=new ContentValues();v.put("name",n);v.put("sort_order",nextOrder());v.put("enabled",1);if(db.getWritableDatabase().insertWithOnConflict("hierarchy_levels",null,v,SQLiteDatabase.CONFLICT_IGNORE)==-1)Toast.makeText(this,"That level already exists",Toast.LENGTH_SHORT).show();refreshAll();}).show();}
    private int nextOrder(){Cursor c=db.getReadableDatabase().rawQuery("SELECT COALESCE(MAX(sort_order),0)+1 FROM hierarchy_levels",null);try{return c.moveToFirst()?c.getInt(0):1;}finally{c.close();}}
    private void editLevel(long id,String old){EditText e=new EditText(this);e.setText(old);e.setSelectAllOnFocus(true);new AlertDialog.Builder(this).setTitle("Rename hierarchy level").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;ContentValues v=new ContentValues();v.put("name",n);db.getWritableDatabase().update("hierarchy_levels",v,"level_id=?",new String[]{String.valueOf(id)});refreshAll();}).show();}
    private void deleteLevel(long id,String name){Cursor c=db.getReadableDatabase().rawQuery("SELECT COUNT(*) FROM organizations WHERE level_id=?",new String[]{String.valueOf(id)});int count=0;try{if(c.moveToFirst())count=c.getInt(0);}finally{c.close();}if(count>0){new AlertDialog.Builder(this).setTitle("Level is in use").setMessage("This level has organizations, so it cannot be deleted.").setPositiveButton("OK",null).show();return;}new AlertDialog.Builder(this).setTitle("Delete level?").setMessage("Delete \""+name+"\"?").setNegativeButton("Cancel",null).setPositiveButton("Delete",(d,w)->{db.getWritableDatabase().delete("hierarchy_levels","level_id=?",new String[]{String.valueOf(id)});refreshAll();}).show();}

    private void editOrganization(Org o){EditText e=new EditText(this);e.setText(o.name);e.setSelectAllOnFocus(true);new AlertDialog.Builder(this).setTitle("Edit organization").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String n=e.getText().toString().trim();if(n.isEmpty())return;ContentValues v=new ContentValues();v.put("name",n);db.getWritableDatabase().update("organizations",v,"organization_id=?",new String[]{String.valueOf(o.id)});refreshAll();}).show();}
    private void editChurch(){SQLiteDatabase s=db.getWritableDatabase();Cursor c=s.query("church_profile",null,null,null,null,null,"church_id ASC","1");final String[] oldName={""};final String[] oldCode={""};try{if(c.moveToFirst()){oldName[0]=c.getString(c.getColumnIndexOrThrow("church_name"));oldCode[0]=c.getString(c.getColumnIndexOrThrow("join_code"));}}finally{c.close();}LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),0,dp(18),0);EditText n=new EditText(this);n.setHint("Church name");n.setText(oldName[0]);box.addView(n);EditText code=new EditText(this);code.setHint("Parent Join Code (optional)");code.setText(oldCode[0]);box.addView(code);new AlertDialog.Builder(this).setTitle("Church / Tenant").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{String name=n.getText().toString().trim();String jc=code.getText().toString().trim();if(name.isEmpty())return;if(jc.isEmpty())jc=makeCode();ContentValues v=new ContentValues();v.put("church_name",name);v.put("join_code",jc);if(oldName[0].isEmpty())v.put("created_at",System.currentTimeMillis());if(oldName[0].isEmpty())s.insertWithOnConflict("church_profile",null,v,SQLiteDatabase.CONFLICT_REPLACE);else s.update("church_profile",v,"church_id=(SELECT church_id FROM church_profile ORDER BY church_id LIMIT 1)",null);refreshChurch();}).show();}
    private String makeCode(){return String.format(Locale.US,"CC-%04d-%04d",new Random().nextInt(10000),new Random().nextInt(10000));}
    private void showLeadership(){startActivity(new android.content.Intent(this,LeadershipManagerActivity.class));}

    private static class ZoomLayout extends FrameLayout {
        private final ScaleGestureDetector detector; private float scale=1f;
        ZoomLayout(Context c){super(c);setClipChildren(false);detector=new ScaleGestureDetector(c,new ScaleGestureDetector.SimpleOnScaleGestureListener(){@Override public boolean onScale(ScaleGestureDetector d){scale*=d.getScaleFactor();if(scale<0.65f)scale=0.65f;if(scale>1.8f)scale=1.8f;setScaleX(scale);setScaleY(scale);return true;}});}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){detector.onTouchEvent(e);return true;}
        @Override public boolean dispatchTouchEvent(android.view.MotionEvent e){detector.onTouchEvent(e);return super.dispatchTouchEvent(e);}
    }

    private class StructureDb extends SQLiteOpenHelper{StructureDb(){super(StructureManagerActivity.this,"churchcare.db",null,ChurchCareDb.VERSION);}@Override public void onCreate(SQLiteDatabase d){ChurchCareDb.ensureAll(d);}@Override public void onUpgrade(SQLiteDatabase d,int oldV,int newV){ChurchCareDb.ensureAll(d);}}
}
