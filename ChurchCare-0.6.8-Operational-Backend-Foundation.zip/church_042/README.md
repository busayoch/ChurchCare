# ChurchCare 0.6.8

Offline-first ChurchCare with an operational local backend foundation.

## Build environment baseline

- Native Android
- Java
- XML layouts
- SQLite
- AndroidX AppCompat + Material
- Gradle wrapper: 8.7
- Android Gradle Plugin: 8.6.1
- compileSdk / targetSdk: 36
- minSdk: 23
- Java source/target: 17
- applicationId: `com.churchcare.app`
- versionCode: 13
- versionName: `0.6.8`

The project includes `build-phone.sh` for ARM64 Android Code Studio environments
where direct Gradle calls require the phone-compatible AAPT2 override.

## 0.6.8 backend foundation

- SQLite remains the authoritative offline database.
- Added stable synchronization IDs through a local `sync_records` registry.
- Added durable `sync_queue` change queue.
- Added `sync_state` for global synchronization status/cursor/error state.
- Existing records are backfilled into the synchronization registry and queued
  for an initial future synchronization.
- SQLite triggers automatically create/update/delete synchronization entries
  when core records change.
- Deletes become tombstones in synchronization metadata rather than immediately
  losing the information needed for a future remote delete.
- Added organization relationship field to members.
- Added organization relationship field to care tickets.
- Added a dedicated delegation table.
- Added a dependency-free `ChurchCareSync` coordinator for future cloud/API
  synchronization.
- Existing five-visit retention behavior remains unchanged.
- Only the thumbnail/profile photo is intended for default cloud synchronization;
  the additional member photos remain local.
- No Google Drive network implementation is included yet; this release prepares
  the local contract for it.

## Important

0.6.7 remains the recovery checkpoint. Do not delete it until 0.6.8 has been
built and tested on the actual Android Code Studio phone environment.
