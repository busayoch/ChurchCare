#!/system/bin/sh
# FieldPulse mobile build helper for Android Code Studio / ARM64 phones.
# Android Code Studio normally injects the AAPT2 override when building from its UI,
# but direct terminal calls (sh gradlew ...) may bypass that injection.
set -e

AAPT2=""
CANDIDATES=""
[ -n "$HOME" ] && CANDIDATES="$CANDIDATES $HOME/.androidide/aapt2"
[ -n "$PREFIX" ] && CANDIDATES="$CANDIDATES $PREFIX/bin/aapt2"
CANDIDATES="$CANDIDATES /data/data/com.tom.rv2ide/files/usr/bin/aapt2"
CANDIDATES="$CANDIDATES /data/data/com.tom.rv2ide/files/home/.androidide/aapt2"

for f in $CANDIDATES; do
  if [ -x "$f" ]; then AAPT2="$f"; break; fi
done

if [ -z "$AAPT2" ] && [ -n "$ANDROID_HOME" ]; then
  for f in "$ANDROID_HOME"/build-tools/*/aapt2; do
    if [ -x "$f" ]; then AAPT2="$f"; break; fi
  done
fi

if [ -z "$AAPT2" ]; then
  echo "ERROR: Could not find an ARM-compatible AAPT2 binary."
  echo "Android Code Studio should provide one. Try building once from the IDE's Build action,"
  echo "or tell me the output of: echo $HOME ; echo $PREFIX ; echo $ANDROID_HOME"
  exit 2
fi

echo "Using phone-compatible AAPT2: $AAPT2"
sh ./gradlew -Pandroid.aapt2FromMavenOverride="$AAPT2" "$@"
